<?php include("Classes/conexao.php");
session_start();
if(isset($_SESSION["profissional"]) && is_array($_SESSION["profissional"])){
  $idMedico = $_SESSION["profissional"][0];
  $nome = $_SESSION["profissional"][1];
}
else{
  header("Location: Login/login.php");
}

?>

<!DOCTYPE html>
<html lang="pt-BR">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Consultas</title>
    <link rel="icon" href="img/logoBranco.png" />
    <link rel="stylesheet" href="css/perfis.css" />
    <script src="js/perfis.js"></script>
    <script
      src="https://kit.fontawesome.com/fdbc06b9ad.js"
      crossorigin="anonymous"
    ></script>
    <!-- <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous"> -->
    <script
      src="https://code.jquery.com/jquery-3.3.1.slim.min.js"
      integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo"
      crossorigin="anonymous"
    ></script>
    <script
      src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"
      integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49"
      crossorigin="anonymous"
    ></script>
    <script
      src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"
      integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy"
      crossorigin="anonymous"
    ></script>
    <link rel="stylesheet" href="css/bootstrap.min.css" />

    <!-- <script src='https://8x8.vc/external_api.js' async></script>
        <style>html, body, #jaas-container { height: 100%; }</style> -->
    <!-- <script type="text/javascript">
          window.onload = () => {
            const api = new JitsiMeetExternalAPI("8x8.vc", {
              roomName: "vpaas-magic-cookie-f447f627cf4c48a7aed4b9d8ed0ae982/SampleAppPastTendenciesHappenPromptly",
              parentNode: document.querySelector('#jaas-container'),
              jwt: "eyJraWQiOiJ2cGFhcy1tYWdpYy1jb29raWUtZjQ0N2Y2MjdjZjRjNDhhN2FlZDRiOWQ4ZWQwYWU5ODIvNWYyZWZjLVNBTVBMRV9BUFAiLCJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJhdWQiOiJqaXRzaSIsImV4cCI6MTYyMjg3NDI5NiwibmJmIjoxNjIyODY3MDkxLCJpc3MiOiJjaGF0Iiwicm9vbSI6IioiLCJzdWIiOiJ2cGFhcy1tYWdpYy1jb29raWUtZjQ0N2Y2MjdjZjRjNDhhN2FlZDRiOWQ4ZWQwYWU5ODIiLCJjb250ZXh0Ijp7ImZlYXR1cmVzIjp7ImxpdmVzdHJlYW1pbmciOmZhbHNlLCJvdXRib3VuZC1jYWxsIjpmYWxzZSwic2lwLW91dGJvdW5kLWNhbGwiOmZhbHNlLCJ0cmFuc2NyaXB0aW9uIjpmYWxzZSwicmVjb3JkaW5nIjpmYWxzZX0sInVzZXIiOnsibW9kZXJhdG9yIjp0cnVlLCJuYW1lIjoiVGVzdCBVc2VyIiwiaWQiOiJhdXRoMHw2MGJhZjdlNTU4M2U0OTAwNmNmNTc5YTkiLCJhdmF0YXIiOiIiLCJlbWFpbCI6InRlc3QudXNlckBjb21wYW55LmNvbSJ9fX0.NP4Tdlsbwd4AEdDr_JputWpDGkPVtVdVeioCPy2lnAsNgkTBXfDVqCFpOZiJs6khmFcmAgW_Z55zxPDJJ1XZXb9CSFX5HnFeeAjkBu4dtSGhCxR6_d89SJDSBbJ_ML4-MbhhgebBWjhBkHCnPJ8Hw-2luzd_5lgcKkuTvouNNcCsAPfEgS66l4-n014IlFfVkZqTjGGU900zSIK3tgXY_cziV8pivmWrC9WtBRwO8T4UX3tZ2nFEftw-yjVGQODljewIX4pmnNAgUO5NIx1tBP9FKAebQh9fRESxk29BtfpOReP6sCUsvjPi3j1lmPlyidISQ9FkaUFY3PBVmEJiZg"
            });
          }
        </script> -->
  </head>
  <body id="body-pd">
    <!-- <div id="jaas-container" /> -->
    <!-- navbar -->
    <div class="l-navbar" id="nav-bar">
      <nav class="nav">
        <div>
          <a
            href="Perfil-Profissional.php"
            style="text-decoration: none"
            class="nav_logo"
          >
            <i class="fas fa-user-md nav_logo-icon"></i><br />
          </a>
          <div class="nav_list">
            <a href="#" style="text-decoration: none" class="nav_link">
              <i class="fas fa-file nav_icon"></i><br />
              <span class="nav_name">Arquivos</span>
            </a>

            <a href="#" style="text-decoration: none" class="nav_link active">
              <i class="fas fa-stethoscope nav_icon"></i><br />
              <span class="nav_name">Consultas</span>
            </a>

            <a href="agendaProfissional.php" style="text-decoration: none" class="nav_link">
              <i class="fas fa-calendar-alt nav_icon"></i><br />
              <span class="nav_name">Agenda</span>
            </a>
          </div>
        </div>
        <a href="#" style="text-decoration: none" class="nav_link">
          <i class="fas fa-cog nav_icon"></i><br />
          <span class="nav_name">Config</span>
        </a>
      </nav>
    </div>

    <a href="Rotinas/logout.php">
    <i
      class="fas fa-sign-out-alt"
      data-toggle="tooltip"
      data-placement="bottom"
      title="Sair"
      id="iconSignOut"
      ></i
    >
    </a><br />

    <h1 id="title_nome" style="overflow-y:hidden;">Nada aqui por enquanto : )</h1>
  </body>
</html>
