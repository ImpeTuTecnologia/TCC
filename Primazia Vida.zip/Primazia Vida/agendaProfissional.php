<?php include("Classes/conexao.php");
session_start();
if(isset($_SESSION["profissional"]) && is_array($_SESSION["profissional"])){
  $idMedico = $_SESSION["profissional"][0];
  $nome = $_SESSION["profissional"][1];
}
else{
  header("Location: Login/login.php");
}

?>

<!DOCTYPE html>
<html lang="pt-BR">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Agenda</title>
    <link
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css"
      rel="stylesheet"
      integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl"
      crossorigin="anonymous"
    />
    <link
      rel="stylesheet"
      href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.0/font/bootstrap-icons.css"
    />
    <link rel="stylesheet" href="css/Style3.css">
    <link rel="stylesheet" href="css/perfis.css">
    <link rel="stylesheet" href="css/bootstrap-grid.min.css" />
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"
    />

    <link rel="icon" href="img/logoBranco.png" />

    <script src="js/perfis.js"></script>
    <script
      src="https://kit.fontawesome.com/fdbc06b9ad.js"
      crossorigin="anonymous"
    ></script>
    <script
      src="https://code.jquery.com/jquery-3.3.1.slim.min.js"
      integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo"
      crossorigin="anonymous"
    ></script>
    <script
      src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"
      integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49"
      crossorigin="anonymous"
    ></script>
    <script
      src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"
      integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy"
      crossorigin="anonymous"
    ></script>
    
    
  </head>
  <body id="body-pd">
    <div class="l-navbar" id="nav-bar">
      <nav class="nav">
        <div>
          <a
            href="Perfil-Profissional.php"
            style="text-decoration: none"
            class="nav_logo"
          >
            <i class="fas fa-user-md nav_logo-icon"></i><br />
          </a>
          <div class="nav_list">
            <a href="#" style="text-decoration: none" class="nav_link">
              <i class="fas fa-file nav_icon"></i><br />
              <span class="nav_name">Arquivos</span>
            </a>

            <a href="chatProfissional.php" style="text-decoration: none" class="nav_link">
              <i class="fas fa-stethoscope nav_icon"></i><br />
              <span class="nav_name">Consultas</span>
            </a>

            <a href="#" style="text-decoration: none" class="nav_link active">
              <i class="fas fa-calendar-alt nav_icon"></i><br />
              <span class="nav_name">Agenda</span>
            </a>
          </div>
        </div>
        <a href="#" style="text-decoration: none" class="nav_link">
          <i class="fas fa-cog nav_icon"></i><br />
          <span class="nav_name">Config</span>
        </a>
      </nav>
    </div>
    <table class="table table-bordered">
      <thead style="background-color: #57010f">
        <tr>
          <th scope="col" class="titulosTabela">Data e Horário</th>
          <th scope="col" class="titulosTabela">Paciente</th>
          <th scope="col" class="titulosTabela">CPF</th>
          <th scope="col"></th>
        </tr>
      </thead>
      <tbody>
          <?php

            include("Classes/conexao.php");
  
            try {
                $stmt = $pdo -> prepare("select * from consulta  
                  inner join tbpaciente on consulta.idPaciente = tbpaciente.idPaciente
                    inner join tbmedico on consulta.idMedico = tbmedico.idMedico
                      where consulta.idMedico = '$idMedico'");
  
                $stmt -> execute();
  
                while ($row = $stmt -> fetch(PDO::FETCH_BOTH)){ 
                                  
                                          
                  echo"<tr>";       
                  echo"<th scope='row'>" .$row['dataConsulta']. " às " . $row['horaConsulta'] . "</th>";
                  echo"<td>" . $row['nome'] . "</td>";
                  echo"<td>" . $row['cpf'] . "</td>";
                  echo"<td><button type='button' id='botaoaceitar'><a href='chatProfissional.php' style='color:#fff;'>Realizar Consulta</a></button></td>";
                  echo"</tr>";
                }
              }
              catch(PDOException $e){
                  echo("Erro: ".$e -> getMessage());
              }
  
          ?>
      </tbody>
    </table>
  </body>
</html>
