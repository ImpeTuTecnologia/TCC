<?php
  session_start();
?>
<!doctype html>
<html lang="pt-br">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- INICIO BOOTSTRAP CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.0/font/bootstrap-icons.css">
    <link rel="stylesheet" href="css/bootstrap-grid.min.css">
    <!--fINAL BOOTSTRAP CSS-->

    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/Style2.css">

    <!--INICIO BOOTSTRAP JS-->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.15/jquery.mask.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.15/jquery.mask.min.js"></script>
    <!--FINAL BOOTSTRAP JS-->

    <script type="text/javascript" src="js/ScriptsCadProf.js"></script>
    <link rel="icon" href="img/logoBranco.png" />
    <title>Cadastro Medico</title>
      
  </head>


  <body style="background-image: url(img/Fundo.jpg)">
    <!--INICIO CABEÇALHO-->
    <nav class="navbar navbar-expand-lg navbar-light bg-" style="background-color: #A71930;">
      <div class="container-fluid">    
        <a class="navbar-brand" href="#"><img src="img/primaziaVinho.jpg" width="180" height="110"></a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarText" aria-controls="navbarText" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarText">
          <ul class="navbar-nav me-auto mb-2 mb-lg-0"></ul>
            <span class="navbar-text" style="font-size: 20px; color:black">
              Sobre o Primazia Vida
            </span>
        </div>
      </div>
    </nav>
    <!--FINAL CABEÇALHO-->

    <br>
 
    <div class="container">   
      <center><b><Font size="6" color="black" face="Bahnschrift Condensed">FAÇA O CADASTRO DO MEDICO</Font></b></center>

      <br>

      <p class="obg">*Obrigatório preencher todos os campos</p>

      <div class="row justify-content-center mb-5">
        <div class="col-sm12 col-md-10 col-lg-8">
          <section>

            <!--INICIO FORMULARIO-->
            <form method="POST" action="../Rotinas/cadastrarAdm.php" onsubmit="return validarTudo()">

                <!--CAMPO NOME-->
                <div class="form-row">
                    <div class="form-grup col-sm-6 col-md-6 col-lg-6">
                        <label for="nome_admSistema">
                            <strong>
                                Nome Completo:
                            </strong>
                        </label>
                        <input type="text" class="form-control" name="nome" id="nome_admSistema" placeholder="Nome" style="border-color: #A71930;">
                    </div>
                </div>

                <br>

                <!--CAMPO CPF e RG-->
                <div class="form-row">
                    <div class="form-grup col-sm-6 col-md-5 col-lg-6">
                        <label for="cpf_admSistema">
                            <strong>
                                CPF: 
                            </strong>
                        </label>
                        <input type="text" class="form-control" name="cpf" id="cpf_admSistema" placeholder="Registro..." style="border-color: #A71930;">
                    </div>

                    <div class="form-grup col-sm-6 col-md-6 col-lg-6">
                        <label for="rg_admSistema">
                            <strong>
                                RG: 
                            </strong>
                        </label>
                        <input type="text" class="form-control" name="rg" id="rg_admSistema" placeholder="Exemplo: Cardiologista" style="border-color: #A71930;">
                    </div>
                </div>

                <br>
                
                <!--CAMPO SEXO e DATA DE NASCIMENTO-->
                <div class="form-row">
                    <div class="form-grup col-sm-4 col-md-4 col-lg-4">
                        <label for="sexo_admSistema">
                            <strong>
                                Sexo:
                            </strong>
                        </label>

                        <select class="form-select" aria-label="Default select example" name="sexo" id="sexo_admSistema"  style="border-color: #A71930;">
                            <option selected>Selecione</option>
                            <option value="m">Feminino</option>
                            <option value="f">Masculino</option>
                            <option value="null">Prefiro não dizer</option>
                        </select>
                    </div>

                    <div class="form-grup col-sm-4 col-md-4 col-lg-4">
                        <label for="dataNasc_admSistema">
                            <strong>
                                Data de Nascimento:
                            </strong>
                        </label>
                        <input type="date" class="form-control" name="dataNasc" id="dataNasc_admSistema" placeholder="Idade..." style="border-color: #A71930;">
                    </div>
                </div>
                
                <br>
                <!--CAMPOS DE ENDEREÇO-->
                <div class="form-row">
                    <div class="form-grup col-sm-4 col-md-4 col-lg-4">
                        <label for="uf_admSistema">
                            <strong>
                                UF: 
                            </strong>
                        </label>
                        <select type="text" class="form-control" name="uf" id="uf_admSistema" style="border-color: #A71930;">                                 
                            <option value="AC">Acre</option>
                            <option value="AL">Alagoas</option>
                            <option value="AP">Amapá</option>
                            <option value="AM">Amazonas</option>
                            <option value="BA">Bahia</option>
                            <option value="CE">Ceará</option>
                            <option value="DF">Distrito Federal</option>
                            <option value="ES">Espírito Santo</option>
                            <option value="GO">Goiás</option>
                            <option value="MA">Maranhão</option>
                            <option value="MT">Mato Grosso</option>
                            <option value="MS">Mato Grosso do Sul</option>
                            <option value="MG">Minas Gerais</option>
                            <option value="PA">Pará</option>
                            <option value="PB">Paraíba</option>
                            <option value="PR">Paraná</option>
                            <option value="PE">Pernambuco</option>
                            <option value="PI">Piauí</option>
                            <option value="RJ">Rio de Janeiro</option>
                            <option value="RN">Rio Grande do Norte</option>
                            <option value="RS">Rio Grande do Sul</option>
                            <option value="RO">Rondônia</option>
                            <option value="RR">Roraima</option>
                            <option value="SC">Santa Catarina</option>
                            <option value="SP">São Paulo</option>
                            <option value="SE">Sergipe</option>
                            <option value="TO">Tocantins</option>                    
                        </select>
                    </div>
                </div>

                <div class="form-grup col-sm-6 col-md-6 col-lg-6">
                        <label for="cidade_admSistema">
                            <strong>
                                Cidade: 
                            </strong>
                        </label>
                        <input type="text" class="form-control" name="cidade" id="cidade_admSistema" placeholder="Nome..." style="border-color: #A71930;">
                </div>

                <br>

                <div class="form-row">
                    <div class="form-grup col-sm-6 col-md-6 col-lg-6">
                        <label for="cep_admSistema">
                            <b>
                                CEP: 
                            </b>
                        </label>
                        <input type="text" class="form-control" name="cep" id="cep_admSistema" placeholder="Nome..." style="border-color: #A71930;">
                    </div>
                </div>

                <br>

                <div class="form-row">
                    <div class="form-grup col-sm-6 col-md-6 col-lg-6">
                            <label for="bairro_admSistema">
                                <b>
                                    Bairro: 
                                </b>
                            </label>
                            <input type="text" class="form-control" name="bairro" id="bairro_admSistema" placeholder="Nome..." style="border-color: #A71930;">
                    </div>
                </div>

                <br>

                <div class="form-row">
                    <div class="form-grup col-sm-6 col-md-6 col-lg-6">
                            <label for="logradouro_admSistema">
                                <strong>
                                    Logradouro: 
                                </strong>
                            </label>
                            <input type="text" class="form-control" name="logradouro" id="logradouro_admSistema" placeholder="Nome..." style="border-color: #A71930;">
                    </div>
                </div>

                <br>

                <div class="form-row">
                    <div class="form-grup col-sm-6 col-md-6 col-lg-6">
                            <label for="numero_admSistema">
                                <strong>
                                    Numero: 
                                </strong>
                            </label>
                            <input type="text" class="form-control" name="numero" id="numero_admSistema" placeholder="Nome..." style="border-color: #A71930;">
                    </div>
                </div>

                <br>

                
                <div class="form-row">
                    <div class="form-grup col-sm-6 col-md-6 col-lg-6">
                            <label for="complemento_admSistema">
                                <strong>
                                    Complemento: 
                                </strong>
                            </label>
                            <input type="text" class="form-control" name="complemento" id="complemento_admSistema" placeholder="Nome..." style="border-color: #A71930;">
                    </div>
                </div>
                
                <br>

                <!--CAMPOS EMAIL e CELULAR-->
                <div class="form-row">
                    <div class="form-grup col-sm-4 col-md-4 col-lg-4">
                        <label for="email_admSistema">
                            <strong>
                                Email: 
                            </strong>
                        </label>
                        <input type="email" class="form-control" name="email" id="email_admSistema" placeholder="Email..." style="border-color: #A71930;">
                    </div>

                    <div class="form-grup col-sm-4 col-md-4 col-lg-4">
                        <label for="celular_admSistema">
                            <strong>
                                Celular: 
                            </strong>
                        </label>
                        <input type="text" class="form-control" name="celular" id="celular_admSistema" placeholder="Email..." style="border-color: #A71930;">
                    </div>
                </div>

                <br>
            
                <!--CAMPOS DE SENHA-->
                <div class="form-row">
                    <div class="form-grup col-sm-4 col-md-4 col-lg-4">
                        <label for="senha_paciente">
                            <strong>
                                Crie sua senha: 
                            </strong>
                        </label>
                        <input type="password" class="form-control" name="senha" id="senha_admSistema" placeholder="Senha..." style="border-color: #A71930;">
                    </div>
         
                    <div class="form-grup col-sm-12 col-md-4 col-lg-4">
                        <label for="confirmarSenha_paciente">
                            <strong>
                                Confirmar senha: 
                            </strong>
                        </label>
                        <input type="password" class="form-control" name="confirmarSenha_admSistema" id="confirmarSenha_admSistema" placeholder="Confirmar..." style="border-color: #A71930;">
                   </div>
                </div>
                
                <br>

                <!--BOTÃO DE ENVIO-->
                <div>
                    <input type="submit" value="Cadastrar" class="bt" onclick="visualizarDados()"/>
                </div>
            </form>
            <!--FINAL FORMULARIIO-->
          </section>
        </div>
      </div>
    </div>  

    <br>

    <footer class=" text-white text-center text-lg-start" style="background-color: #A71930; padding:8px">
     <div class="vida">@PRIMAZIA VIDA 2021</div>
    </footer> 
  
  </body>       
</html>

