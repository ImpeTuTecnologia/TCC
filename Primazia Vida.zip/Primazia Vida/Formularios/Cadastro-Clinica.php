<!doctype html>
<html lang="pt-br">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
      
   
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">

    <link rel="stylesheet" href="css/bootstrap.min.css">
      
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">


    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.0/font/bootstrap-icons.css">
    <link rel="stylesheet" type="text/css" href="../css/style.css"/>
    <link rel="stylesheet" type="text/css" href="../css/Style2.css"/> 
    <link rel="stylesheet" href="../css/bootstrap-grid.min.css">
    <link rel="stylesheet" href="../Home.php">


    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"
            integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4="
            crossorigin="anonymous"></script>
    <!-- link do arquivo que executa o autopreenchimento do cep -->
   <script src="../js/cep.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.15/jquery.mask.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.15/jquery.mask.min.js"></script>

    <script type="text/javascript" src="../js/ScriptsCadClinica.js"></script>

    <link rel="icon" href="img/logoBranco.png" />
   
    <title>Cadastro Clínica</title>
      
  </head>
  <body style="background-image: url(../img/Fundo.jpg)">

  <nav class="navbar navbar-expand-lg navbar-light bg-" style="background-color: #A71930;">
  <div class="container-fluid">
    <a class="navbar-brand" href="../Home.php"><img src="../img/primaziaVinho.jpg" width="210" height="130"></a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarText" aria-controls="navbarText" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarText">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="Cadastro-Paciente.php" style="font-size: 20px; font-weight:bold;">Cadastrar-se</a>
        </li>
        <li class="nav-item">
        <a class="nav-link active" aria-current="page" href="login.php" style="font-size: 20px; font-weight:bold;">Fazer Login</a>
        </li>
        <li class="nav-item">
        <a class="nav-link active" aria-current="page" href="#" style="font-size: 20px;font-weight:bold;">Cadastre sua clínica</a>
        </li>
      </ul>
      <a class="nav-link active" aria-current="page" href="../Sobre.php" style="font-size: 20px; color:black; font-weight:bold;">
        Sobre o Primazia Vida!
      </a>
    </div>
  </div>
</nav>
    <br>
 
    <div class="container">
   
<center><b><Font size="6" color="black" face="Bahnschrift Condensed">CADASTRE SUA CLÍNICA</Font></b></center>
<br>
<p class="obg">*Obrigatório preencher todos os campos</p>

    <div class="row justify-content-center mb-5">

    <div class="col-sm12 col-md-10 col-lg-8">

<section>
 <form action="../Rotinas/cadastrarClinica.php" method="POST" onsubmit="return validarTudo()">

          <div class="form-row">

     
            <div class="form-grup col-sm-8 col-md-8 col-lg-8">

                <label for="LabelNome"><b>Nome:</b></label>
                <input type="text" class="form-control" name="nome" id="txNome" placeholder="Nome..." style="border-color: #A71930;">
             </div>

             <div class="form-grup col-sm-4 col-md-4 col-lg-3">

                <label for="LabelSobreNome"><b>CNPJ: </b></label>
                <input type="text" class="form-control" name="cnpj" id="txCnpj" onkeypress="$(this).mask('00.000.000/0000-00');" placeholder="__.___.___/____-__" style="border-color: #A71930;">
                
             </div>
           
     </div>
     <br>

     <div class="form-row">

        <div class="form-grup col-sm-4 col-md-4 col-lg-5">

            <label for="labelCidade"><b>Inscrição estadual: </b></label>
            <input type="text" class="form-control" name="inscrição" id="txInscricao" onkeypress="$(this).mask('00.000000-0');" placeholder="__._______-_" style="border-color: #A71930;">
  
         </div>

        
      <div class="form-grup col-sm-4 col-md-4 col-lg-6">

          <label for="labelCidade"><b>Data de inicio: </b></label>
          <input type="date" class="form-control" name="data" id="txData" placeholder="dd/mm/aaaa..." style="border-color: #A71930;">

       </div>
   
    
        <!-- <div class="form-grup col-sm-4 col-md-4 col-lg-4">

            <label for="labelCidade"><b>Área atuante: </b></label>
            <input type="text" class="form-control" name="area" id="txArea" placeholder="Exemplo: Cardiologia" style="border-color: #A71930;">

         </div> -->
    </div>
    <br>
     
     <div class="form-row">

     
      <div class="form-grup col-sm-8 col-md-8 col-lg-8">

          <label for="LabelNome"><b>Responsável legal: </b></label>
          <input type="text" class="form-control" name="responsável" id="txResponsavel" placeholder="Responsável..." style="border-color: #A71930;">

       </div>

       <div class="form-grup col-sm-4 col-md-4 col-lg-4">

          <label for="LabelSobreNome"><b>CPF: </b></label>
          <input type="text" class="form-control" name="cpf" id="txCpf" onkeypress="$(this).mask('000.000.000-00');" placeholder="___.___.___-__" style="border-color: #A71930;">
          
       </div>
     
</div>
<br>

        <div class="form-row">
            
         <div class="form-grup col-sm-4 col-md-4 col-lg-4">
        
            <label for="labelCep"><b>CEP: </b></label>
            <input type="text" class="form-control" name="cep" id="txCep" onkeypress="$(this).mask('00000-000');" placeholder="_____-___" style="border-color: #A71930;">

         </div>

         <div class="form-grup col-sm-7 col-md-7 col-lg-6">
        
            <label for="labelEndereço"><b>Endereço: </b></label>
            <input type="text" class="form-control" name="endereço" id="txLog" placeholder="Endereço..." style="border-color: #A71930;">

         </div>

       
             <div class="form-grup col-sm-2 col-md-2 col-lg-2">
        
                <label for="labelN"><b>N°: </b></label>
                <input type="number" class="form-control" name="n" id="txN" placeholder="N°..." style="border-color: #A71930;">

             </div>

             

        </div>
        <br>

        <div class="form-row">
         
         <div class="form-grup col-sm-3 col-md-3 col-lg-4">
        
            <label for="labelN"><b>Complemento: </b></label>
            <input type="text" class="form-control" name="complemento" id="txCompl" placeholder="Complemento..." style="border-color: #A71930;">

         </div>

            

             <div class="form-grup col-sm-4 col-md-4 col-lg-3.5">
        
                <label for="labelBairro"><b>Bairro: </b></label>
                <input type="text" class="form-control" name="bairro" id="txBairro" placeholder="Bairro..." style="border-color: #A71930;">

             </div>

             <div class="form-grup col-sm-4 col-md-4 col-lg-3.5">
        
                <label for="labelCidade"><b>Cidade: </b></label>
                <input type="text" class="form-control" name="cidade" id="txCidade" placeholder="Cidade..." style="border-color: #A71930;">

             </div>

        </div>
        <br>

        <div class="form-row">
            
            <div class="form-grup col-sm-2 col-md-2 col-lg-2">
        
                <label for="labelCep"><b>UF: </b></label>
                <select type="text" class="form-control" name="uf" id="txUf" placeholder="UF..." style="border-color: #A71930;">
                
                  <option value="AC">Acre</option>
                  <option value="AL">Alagoas</option>
                  <option value="AP">Amapá</option>
                  <option value="AM">Amazonas</option>
                  <option value="BA">Bahia</option>
                  <option value="CE">Ceará</option>
                  <option value="DF">Distrito Federal</option>
                  <option value="ES">Espírito Santo</option>
                  <option value="GO">Goiás</option>
                  <option value="MA">Maranhão</option>
                  <option value="MT">Mato Grosso</option>
                  <option value="MS">Mato Grosso do Sul</option>
                  <option value="MG">Minas Gerais</option>
                  <option value="PA">Pará</option>
                  <option value="PB">Paraíba</option>
                  <option value="PR">Paraná</option>
                  <option value="PE">Pernambuco</option>
                  <option value="PI">Piauí</option>
                  <option value="RJ">Rio de Janeiro</option>
                  <option value="RN">Rio Grande do Norte</option>
                  <option value="RS">Rio Grande do Sul</option>
                  <option value="RO">Rondônia</option>
                  <option value="RR">Roraima</option>
                  <option value="SC">Santa Catarina</option>
                  <option value="SP">São Paulo</option>
                  <option value="SE">Sergipe</option>
                  <option value="TO">Tocantins</option>
                
                </select>

             </div>

             <div class="form-grup col-sm-5 col-md-5 col-lg-5">
        
                <label for="labelBairro"><b>Telefone: </b></label>
                <input type="text" class="form-control" name="telefone" id="txFone" onkeypress="$(this).mask('(00) 0000-0000');" placeholder="( __ )____-____" style="border-color: #A71930;">

             </div>

             <div class="form-grup col-sm-5 col-md-5 col-lg-5">
        
                <label for="labelBairro"><b>Celular: </b></label>
                <input type="text" class="form-control" name="celular" id="txCell" onkeypress="$(this).mask('(00) 0000-0000');" placeholder="( __ )____-____" style="border-color: #A71930;">

             </div>

        </div>
        <br>

               

                  <div class="form-row">

        
                    <div class="form-grup col-sm-4 col-md-4 col-lg-4">
        
                        <label for="labelCidade"><b>Email: </b></label>
                        <input type="email" class="form-control" name="email" id="txEmail" placeholder="Email..." style="border-color: #A71930;">
        
                     </div>
                 
                  
                      <div class="form-grup col-sm-4 col-md-4 col-lg-4">
          
                          <label for="labelCidade"><b>Crie sua senha: </b></label>
                          <input type="password" class="form-control" name="senha" id="txSenha" placeholder="Senha..." style="border-color: #A71930;">
          
                      </div>
                 
                          <div class="form-grup col-sm-12 col-md-4 col-lg-4">
        
                        <label for="labelCep"><b>Confirmar senha: </b></label>
                        <input type="password" class="form-control" name="confirmar" id="txConfirmar" placeholder="Confirmar..." style="border-color: #A71930;">
        
                          </div>
                          <br>
                     <div class="form-row">
                          <div>
                              <input type="submit" value="Cadastrar" class="bt" onclick="visualizarDados()"/>
                          </div>
                     </div>
            </form>
         </section>

</div>
</div>
<section>
  <p id="resultado" class="result"></p>
</section>

</div>  
<br>
<footer class=" text-white text-center text-lg-start" style="background-color: #A71930; margin-top:8%;">
    <!-- Grid container -->
      <!-- Footer Links -->
  <div class="container text-center text-md-left">

    <!-- Grid row -->
    <div class="row">

      <!-- Grid column -->
      <hr class="clearfix w-100 d-md-none">

      <!-- Grid column -->
      <div class="col-md-4 col-lg-3 mx-auto my-md-4 my-0 mt-4 mb-1">

        <!-- Contact details -->
        <h5 class="email">E-Mail</h5>

        <ul class="list-unstyled">
          <li>
              <p class="email2">PrimaziaVida@gmail.com</p>
          </li>
        </ul>

      </div>
      <!-- Grid column -->

      <hr class="clearfix w-100 d-md-none">

      <!-- Grid column -->
      <div class="col-md-4 col-lg-3 mx-auto my-md-4 my-0 mt-4 mb-1">

        <!-- Contact details -->
        <h5 class="insta">Instagram</h5>

        <ul class="list-unstyled">
          <li>
              <p class="insta2">@PrimaziaVida(Oficial)</p>
          </li>
        </ul>

      </div>
      <!-- Grid column -->

      <hr class="clearfix w-100 d-md-none">

      <!-- Grid column -->
      <div class="col-md-4 col-lg-3 mx-auto my-md-4 my-0 mt-4 mb-1">

        <!-- Contact details -->
        <h5 class="yt">Youtube</h5>

        <ul class="list-unstyled">
          <li>
              <p class="yt2">Primazia Vida Oficial</p>
          </li>
        </ul>

      </div>
      <!-- Grid column -->

      <hr class="clearfix w-100 d-md-none">

      <!-- Grid column -->
      <div class="col-md-4 col-lg-3 mx-auto my-md-4 my-0 mt-4 mb-1">

        <!-- Contact details -->
        <h5 class="emp">Empresa</h5>

        <ul class="list-unstyled">
          <li>
              <a href="#"><p class="emp2">ImpetuTecnologia.com</p></a>
          </li>
        </ul>

      </div>
      <!-- Grid column -->

    </div>
    <!-- Grid row -->

  </div>
  <!-- Footer Links -->

  <!-- Copyright -->
  <div class="vida">&copy; PRIMAZIA VIDA 2021</div>
  <!-- Copyright -->

</footer>
<!-- Footer -->
</body>       
</html>

