<!doctype html>
<html lang="pt-br">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
      
   <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">

    <link rel="stylesheet" href="../css/bootstrap.min.css">
      
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
      
    <link rel="stylesheet" href="../Home.php">

    <link rel="icon" href="../img/logoBranco.png" />
   
    <link rel="stylesheet" type="text/css" href="../css/style.css"/>
    <link rel="stylesheet" type="text/css" href="../css/Style2.css"/>

    <title>Login</title>
      
  </head>
  <body style="background-image: url(../img/Fundo.jpg)">

  <nav class="navbar navbar-expand-lg navbar-light bg-" style="background-color: #A71930;">
  <div class="container-fluid">
    <a class="navbar-brand" href="../Home.php"><img src="../img/primaziaVinho.jpg" width="210" height="130"></a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarText" aria-controls="navbarText" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarText">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="Cadastro-Paciente.php" style="font-size: 20px; font-weight:bold;">Cadastrar-se</a>
        </li>
        <li class="nav-item">
        <a class="nav-link active" aria-current="page" href="#" style="font-size: 20px; font-weight:bold;">Fazer Login</a>
        </li>
        <li class="nav-item">
        <a class="nav-link active" aria-current="page" href="Cadastro-Clinica.php" style="font-size: 20px; font-weight:bold;">Cadastre sua clínica</a>
        </li>
      </ul>
      <a class="nav-link active" aria-current="page" href="../Sobre.php" style="font-size: 20px; color:black; font-weight:bold;">
        Sobre o Primazia Vida!
      </a>
    </div>
  </div>
</nav>
    <br><br>

   <div class="container">

    <center><b><Font size="6" color="black" face="Bahnschrift Condensed">FAÇA SEU LOGIN</Font></b></center>
<br>

<div class="row justify-content-center mb-5">

    <div class="col-sm12 col-md-10 col-lg-8">

 <form name="login" method="POST" action="../Rotinas/logar.php">

          <div class="form-row">

     
          <div class="form-grup col-sm-4 col-md-4 col-lg-4">

                <label for="LabelNome"><b>Digite seu email: </b></label>
                <input type="text" class="form-control" name="email" id="inputNome" placeholder="Email..." style="border-color: #A71930;">

             </div>

             <div class="form-grup col-sm-4 col-md-4 col-lg-4">
             <label for="LabelSobreNome"><b>Como gostaria de entrar?</b></label>
              <select class="form-select" aria-label="Default select example" name="opcao" id="opcao-login" style="border-color: #A71930;">
                <option value="1">Paciente</option>
                <option value="2">Administrador de Clinica</option>
                <option value="3">Profissional</option>
              </select>
            </div> 

             <div class="form-grup col-sm-4 col-md-4 col-lg-4">

                <label for="LabelSobreNome"><b>Digite sua senha: </b></label>
                <input type="password" class="form-control" name="senha" id="inputSobreNome" placeholder="Senha..." style="border-color: #A71930;">

             </div>    
     </div>
     <br>
     <div>
      <input type="submit" value="Entrar" name="logar" class="bt" onclick="visualizarDados()" style="margin-left:35%;">
           </div>
     <br>

   </div>
   </div>
   </div>
   <br>
   
   <footer class=" text-white text-center text-lg-start" style="background-color: #A71930; margin-top:8%;">
    <!-- Grid container -->
      <!-- Footer Links -->
  <div class="container text-center text-md-left">

    <!-- Grid row -->
    <div class="row">

      <!-- Grid column -->
      <hr class="clearfix w-100 d-md-none">

      <!-- Grid column -->
      <div class="col-md-4 col-lg-3 mx-auto my-md-4 my-0 mt-4 mb-1">

        <!-- Contact details -->
        <h5 class="email">E-Mail</h5>

        <ul class="list-unstyled">
          <li>
              <p class="email2">PrimaziaVida@gmail.com</p>
          </li>
        </ul>

      </div>
      <!-- Grid column -->

      <hr class="clearfix w-100 d-md-none">

      <!-- Grid column -->
      <div class="col-md-4 col-lg-3 mx-auto my-md-4 my-0 mt-4 mb-1">

        <!-- Contact details -->
        <h5 class="insta">Instagram</h5>

        <ul class="list-unstyled">
          <li>
              <p class="insta2">@PrimaziaVida(Oficial)</p>
          </li>
        </ul>

      </div>
      <!-- Grid column -->

      <hr class="clearfix w-100 d-md-none">

      <!-- Grid column -->
      <div class="col-md-4 col-lg-3 mx-auto my-md-4 my-0 mt-4 mb-1">

        <!-- Contact details -->
        <h5 class="yt">Youtube</h5>

        <ul class="list-unstyled">
          <li>
              <p class="yt2">Primazia Vida Oficial</p>
          </li>
        </ul>

      </div>
      <!-- Grid column -->

      <hr class="clearfix w-100 d-md-none">

      <!-- Grid column -->
      <div class="col-md-4 col-lg-3 mx-auto my-md-4 my-0 mt-4 mb-1">

        <!-- Contact details -->
        <h5 class="emp">Empresa</h5>

        <ul class="list-unstyled">
          <li>
              <a href="#"><p class="emp2">ImpetuTecnologia.com</p></a>
          </li>
        </ul>

      </div>
      <!-- Grid column -->

    </div>
    <!-- Grid row -->

  </div>
  <!-- Footer Links -->

  <!-- Copyright -->
  <div class="vida">&copy; PRIMAZIA VIDA 2021</div>
  <!-- Copyright -->

</footer>
<!-- Footer -->


   </body>
   </html>