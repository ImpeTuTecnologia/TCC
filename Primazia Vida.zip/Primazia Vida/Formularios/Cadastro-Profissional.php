<!DOCTYPE html>
<html lang="pt-br">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8" />
    <meta
      name="viewport"
      content="width=device-width, initial-scale=1, shrink-to-fit=no"
    />

    <!-- Bootstrap CSS -->
    <link
      rel="stylesheet"
      href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css"
      integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk"
      crossorigin="anonymous"
    />

    <link
      rel="stylesheet"
      href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css"
      integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk"
      crossorigin="anonymous"
    />

    <link rel="stylesheet" href="css/bootstrap.min.css" />

    <link
      rel="stylesheet"
      href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css"
      integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN"
      crossorigin="anonymous"
    />

    <link
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css"
      rel="stylesheet"
      integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl"
      crossorigin="anonymous"
    />
    <link
      rel="stylesheet"
      href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.0/font/bootstrap-icons.css"
    />
    <link rel="stylesheet" type="text/css" href="../css/style.css" />
    <link rel="stylesheet" type="text/css" href="../css/Style2.css" />
    <link rel="stylesheet" href="../css/bootstrap-grid.min.css" />

    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
    <!-- link do script do jquery para utilizar web service de cep -->
    <script
      src="https://code.jquery.com/jquery-3.6.0.min.js"
      integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4="
      crossorigin="anonymous"
    ></script>
    <!-- link do arquivo que executa o autopreenchimento do cep -->
    <script src="../js/cep.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.15/jquery.mask.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.15/jquery.mask.min.js"></script>

    <script type="text/javascript" src="../js/ScriptsCadProf.js"></script>

    <link rel="icon" href="img/logoBranco.png" />

    <title>Cadastro Profissional</title>
  </head>
  <body style="background-image: url(../img/Fundo.jpg)">
    <nav
      class="navbar navbar-expand-lg navbar-light bg-"
      style="background-color: #a71930"
    >
      <div class="container-fluid">
        <a class="navbar-brand" href="#"
          ><img src="../img/primaziaVinho.jpg" width="180" height="110"
        /></a>
        <button
          class="navbar-toggler"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#navbarText"
          aria-controls="navbarText"
          aria-expanded="false"
          aria-label="Toggle navigation"
        >
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarText">
          <ul class="navbar-nav me-auto mb-2 mb-lg-0"></ul>
        </div>
      </div>
    </nav>
    <br />

    <div class="container">
      <center>
        <b
          ><font size="6" color="black" face="Bahnschrift Condensed"
            >FAÇA O CADASTRO DO PROFISSIONAL</font
          ></b
        >
      </center>
      <br />
      <p class="obg">*Obrigatório preencher todos os campos</p>

      <div class="row justify-content-center mb-5">
        <div class="col-sm12 col-md-10 col-lg-8">
          <section>
            <form
              action="../Rotinas/cadastrarProfissional.php"
              method="POST"
              onsubmit="return validarTudo()"
            >
              <div class="form-row">
                <div class="form-grup col-sm-6 col-md-6 col-lg-6">
                  <label for="LabelNome"><b>Nome:</b></label>
                  <input
                    type="text"
                    class="form-control"
                    name="nome"
                    id="txNome"
                    placeholder="Nome..."
                    style="border-color: #a71930"
                  />
                </div>

                <!-- <div class="form-grup col-sm-6 col-md-6 col-lg-6">

                <label for="LabelSobreNome"><b>Sobrenome: </b></label>
                <input type="text" class="form-control" name="sobrenome" id="txSobrenome" placeholder="Sobrenome..." style="border-color: #A71930;">
                
             </div> -->
              </div>
              <br />

              <div class="form-row">
                <div class="form-grup col-sm-6 col-md-6 col-lg-6">
                  <label for="labelCidade"><b>CRM: </b></label>
                  <input
                    type="text"
                    class="form-control"
                    name="numero"
                    id="txRegistro"
                    onkeypress="$(this).mask('00000000-0');"
                    placeholder="________ - _"
                    style="border-color: #a71930"
                  />
                </div>

                <div class="form-grup col-sm-6 col-md-6 col-lg-6">
                  <label for="labelCidade"><b>Área que exerce: </b></label>
                  <input
                    type="text"
                    class="form-control"
                    name="area"
                    id="txArea"
                    placeholder="Exemplo: Cardiologista"
                    style="border-color: #a71930"
                  />
                </div>
              </div>
              <br />

              <div class="form-row">
                <div class="form-grup col-sm-4 col-md-4 col-lg-4">
                  <label for="LabelNome"><b>Data de Nascimento: </b></label>
                  <input
                    type="date"
                    class="form-control"
                    name="data"
                    id="txData"
                    placeholder="Idade..."
                    style="border-color: #a71930"
                  />
                </div>

                <div class="form-grup col-sm-4 col-md-4 col-lg-4">
                  <label for="LabelSobreNome"><b>RG: </b></label>
                  <input
                    type="text"
                    class="form-control"
                    name="rg"
                    onkeypress="$(this).mask('00.000.000-0');"
                    id="txRg"
                    placeholder="__.___.___-_"
                    style="border-color: #a71930"
                  />
                </div>

                <div class="form-grup col-sm-4 col-md-4 col-lg-4">
                  <label for="labelCidade"><b>CPF: </b></label>
                  <input
                    type="text"
                    class="form-control"
                    name="cpf"
                    onkeypress="$(this).mask('000.000.000-00');"
                    id="txCpf"
                    placeholder="___.___.___-__"
                    style="border-color: #a71930"
                  />
                </div>
              </div>
              <br />

              <div class="form-row">
                <div class="form-grup col-sm-4 col-md-4 col-lg-4">
                  <label for="labelCidade"><b>Email: </b></label>
                  <input
                    type="email"
                    class="form-control"
                    name="email"
                    id="txEmail"
                    placeholder="Email..."
                    style="border-color: #a71930"
                  />
                </div>

                <div class="form-grup col-sm-4 col-md-4 col-lg-4">
                  <label for="labelCidade"><b>Crie sua senha: </b></label>
                  <input
                    type="password"
                    class="form-control"
                    name="senha"
                    id="txSenha"
                    placeholder="Senha..."
                    style="border-color: #a71930"
                  />
                </div>

                <div class="form-grup col-sm-12 col-md-4 col-lg-4">
                  <label for="labelCep"><b>Confirmar senha: </b></label>
                  <input
                    type="password"
                    class="form-control"
                    name="confirmar"
                    id="txConfirmar"
                    placeholder="Confirmar..."
                    style="border-color: #a71930"
                  />

                  <br />
                </div>
              </div>
              <div>
                <input
                  type="submit"
                  value="Cadastrar"
                  class="bt"
                  style="margin-left: 38%"
                  onclick="visualizarDados()"
                />
              </div>
            </form>
          </section>
        </div>
      </div>
      <section>
        <p id="resultado" class="result"></p>
      </section>
    </div>
    <br />
    <footer
      class="text-white text-center text-lg-start"
      style="background-color: #a71930; padding: 8px"
    >
      <!-- Grid container -->
      <!-- Copyright -->
      <div class="vida">&copy; PRIMAZIA VIDA 2021</div>
      <!-- Copyright -->
    </footer>
  </body>
</html>
