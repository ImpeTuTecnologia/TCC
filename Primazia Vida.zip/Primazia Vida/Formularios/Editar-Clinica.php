<?php include("../Classes/conexao.php");
  //  $idPaciente = $_GET['idPaciente'];
  session_start();
if(isset($_SESSION["clinica"]) && is_array($_SESSION["clinica"])){
  $idClinica = $_SESSION["clinica"][0];
  $nome = $_SESSION["clinica"][1];
}
else{
  header("Location: Login/login.php");
}
  try{
    $stmt = $pdo -> prepare ("select * from tbclinica where idClinica = '$idClinica'");
    $stmt -> execute();
    $row = $stmt ->fetch(PDO::FETCH_BOTH);
  }catch(PDOException $e){
    echo "ERRO: " . $e->getMessage();
  }
  
?> 

<!doctype html>
<html lang="pt-br">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
      
   
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">

    <link rel="stylesheet" href="css/bootstrap.min.css">
      
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">


    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.0/font/bootstrap-icons.css">
    <link rel="stylesheet" type="text/css" href="../css/style.css"/>
    <link rel="stylesheet" type="text/css" href="../css/Style2.css"/> 
    <link rel="stylesheet" href="../css/bootstrap-grid.min.css">
    <link rel="stylesheet" href="../Home.php">


    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"
            integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4="
            crossorigin="anonymous"></script>
    <!-- link do arquivo que executa o autopreenchimento do cep -->
   <script src="../js/cep.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.15/jquery.mask.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.15/jquery.mask.min.js"></script>

    <script type="text/javascript" src="../js/ScriptsCadClinica.js"></script>

    <link rel="icon" href="img/logoBranco.png" />
   
    <title>Editar Dados</title>
      
  </head>
  <body style="background-image: url(../img/Fundo.jpg)">

  <nav class="navbar navbar-expand-lg navbar-light bg-" style="background-color: #A71930;">
  <div class="container-fluid">
    <a class="navbar-brand" href="#"><img src="../img/primaziaVinho.jpg" width="180" height="110"></a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarText" aria-controls="navbarText" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarText">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0"></ul>
    </div>
    
  </div>
</nav>
    <br>
 
    <div class="container">
   
<center><b><Font size="6" color="black" face="Bahnschrift Condensed">EDITAR DADOS DA CLÍNICA</Font></b></center>
<br>


    <div class="row justify-content-center mb-5">

    <div class="col-sm12 col-md-10 col-lg-8">

<section>
 <form action="../Rotinas/alterarClinica.php" method="POST" onsubmit="return validarTudo()">

          <div class="form-row">

     
            <div class="form-grup col-sm-8 col-md-8 col-lg-8">

                <label for="LabelNome"><b>Nome:</b></label>
                <input type="text" class="form-control" name="nome" id="txNome" value="<?php echo $row['nome']; ?>" placeholder="Nome..." style="border-color: #A71930;">
             </div>

             <div class="form-grup col-sm-4 col-md-4 col-lg-3">

                <label for="LabelSobreNome"><b>CNPJ: </b></label>
                <input type="text" class="form-control" name="cnpj" id="txCnpj" value="<?php echo $row['cnpj']; ?>" onkeypress="$(this).mask('00.000.000/0000-00');" placeholder="__.___.___/____-__" style="border-color: #A71930;">
                
             </div>
           
     </div>
     <br>

     <div class="form-row">

        <div class="form-grup col-sm-4 col-md-4 col-lg-5">

            <label for="labelCidade"><b>Inscrição estadual: </b></label>
            <input type="text" class="form-control" name="inscrição" id="txInscricao" value="<?php echo $row['inscricaoEstadual']; ?>" onkeypress="$(this).mask('00.000000-0');" placeholder="__._______-_" style="border-color: #A71930;">
  
         </div>

        
      <div class="form-grup col-sm-4 col-md-4 col-lg-6">

          <label for="labelCidade"><b>Data de inicio: </b></label>
          <input type="date" class="form-control" name="data" id="txData" value="<?php echo $row['data_inicio']; ?>" placeholder="dd/mm/aaaa..."  style="border-color: #A71930;">

       </div>
   
    
        <!-- <div class="form-grup col-sm-4 col-md-4 col-lg-4">

            <label for="labelCidade"><b>Área atuante: </b></label>
            <input type="text" class="form-control" name="area" id="txArea" placeholder="Exemplo: Cardiologia" style="border-color: #A71930;">

         </div> -->
    </div>
    <br>
     
     <div class="form-row">

     
      <div class="form-grup col-sm-8 col-md-8 col-lg-8">

          <label for="LabelNome"><b>Responsável legal: </b></label>
          <input type="text" class="form-control" name="responsável" id="txResponsavel" value="<?php echo $row['responsaveLegal']; ?>" placeholder="Responsável..." style="border-color: #A71930;">

       </div>

       <div class="form-grup col-sm-4 col-md-4 col-lg-4">

          <label for="LabelSobreNome"><b>CPF: </b></label>
          <input type="text" class="form-control" name="cpf" id="txCpf" value="<?php echo $row['cpfResponsavel']; ?>" onkeypress="$(this).mask('000.000.000-00');" placeholder="___.___.___-__" style="border-color: #A71930;">
          
       </div>
     
</div>
<br>

        <div class="form-row">
            
         <div class="form-grup col-sm-4 col-md-4 col-lg-4">
        
            <label for="labelCep"><b>CEP: </b></label>
            <input type="text" class="form-control" name="cep" id="txCep" value="<?php echo $row['cep']; ?>" onkeypress="$(this).mask('00000-000');" placeholder="_____-___" style="border-color: #A71930;">

         </div>

         <div class="form-grup col-sm-7 col-md-7 col-lg-6">
        
            <label for="labelEndereço"><b>Endereço: </b></label>
            <input type="text" class="form-control" name="endereço" id="txLog" placeholder="Endereço..." value="<?php echo $row['logradouro']; ?>" style="border-color: #A71930;">

         </div>

       
             <div class="form-grup col-sm-2 col-md-2 col-lg-2">
        
                <label for="labelN"><b>N°: </b></label>
                <input type="number" class="form-control" name="n" id="txN" value="<?php echo $row['numero']; ?>" placeholder="N°..." style="border-color: #A71930;">

             </div>

             

        </div>
        <br>

        <div class="form-row">
         
         <div class="form-grup col-sm-3 col-md-3 col-lg-4">
        
            <label for="labelN"><b>Complemento: </b></label>
            <input type="text" class="form-control" name="complemento" id="txCompl" value="<?php echo $row['complemento']; ?>" placeholder="Complemento..." style="border-color: #A71930;">

         </div>

            

             <div class="form-grup col-sm-4 col-md-4 col-lg-3.5">
        
                <label for="labelBairro"><b>Bairro: </b></label>
                <input type="text" class="form-control" name="bairro" id="txBairro" value="<?php echo $row['bairro']; ?>" placeholder="Bairro..." style="border-color: #A71930;">

             </div>

             <div class="form-grup col-sm-4 col-md-4 col-lg-3.5">
        
                <label for="labelCidade"><b>Cidade: </b></label>
                <input type="text" class="form-control" name="cidade" id="txCidade" value="<?php echo $row['cidade']; ?>" placeholder="Cidade..." style="border-color: #A71930;">

             </div>

        </div>
        <br>

        <div class="form-row">
            
            <div class="form-grup col-sm-2 col-md-2 col-lg-2">
        
                <label for="labelCep"><b>UF: </b></label>
                <select type="text" class="form-control" name="uf" id="txUf" value="<?php echo $row['uf']; ?>" placeholder="UF..." style="border-color: #A71930;">
                
                  <option value="AC">Acre</option>
                  <option value="AL">Alagoas</option>
                  <option value="AP">Amapá</option>
                  <option value="AM">Amazonas</option>
                  <option value="BA">Bahia</option>
                  <option value="CE">Ceará</option>
                  <option value="DF">Distrito Federal</option>
                  <option value="ES">Espírito Santo</option>
                  <option value="GO">Goiás</option>
                  <option value="MA">Maranhão</option>
                  <option value="MT">Mato Grosso</option>
                  <option value="MS">Mato Grosso do Sul</option>
                  <option value="MG">Minas Gerais</option>
                  <option value="PA">Pará</option>
                  <option value="PB">Paraíba</option>
                  <option value="PR">Paraná</option>
                  <option value="PE">Pernambuco</option>
                  <option value="PI">Piauí</option>
                  <option value="RJ">Rio de Janeiro</option>
                  <option value="RN">Rio Grande do Norte</option>
                  <option value="RS">Rio Grande do Sul</option>
                  <option value="RO">Rondônia</option>
                  <option value="RR">Roraima</option>
                  <option value="SC">Santa Catarina</option>
                  <option value="SP">São Paulo</option>
                  <option value="SE">Sergipe</option>
                  <option value="TO">Tocantins</option>
                
                </select>

             </div>

             <div class="form-grup col-sm-5 col-md-5 col-lg-5">
        
                <label for="labelBairro"><b>Telefone: </b></label>
                <input type="text" class="form-control" name="telefone" id="txFone" value="<?php echo $row['telefone']; ?>" onkeypress="$(this).mask('(00) 0000-0000');" placeholder="( __ )____-____" style="border-color: #A71930;">

             </div>

             <div class="form-grup col-sm-5 col-md-5 col-lg-5">
        
                <label for="labelBairro"><b>Celular: </b></label>
                <input type="text" class="form-control" name="celular" id="txCell" value="<?php echo $row['celular']; ?>" onkeypress="$(this).mask('(00) 0000-0000');" placeholder="( __ )____-____" style="border-color: #A71930;">

             </div>

        </div>
      

               
                     <input type="submit" value="Salvar Alterações" class="bt" style="margin-left:40%;" onclick="visualizarDados()"/>
</form>
</section>

</div>
</div>
<section>
  <p id="resultado" class="result"></p>
</section>

</div>  
<br>
   <footer class=" text-white text-center text-lg-start" style="background-color: #A71930; padding:8px">
   <!-- Grid container -->
 <!-- Copyright -->
 <div class="vida">&copy; PRIMAZIA VIDA 2021</div>
 <!-- Copyright -->
</footer> 
</body>       
</html>

