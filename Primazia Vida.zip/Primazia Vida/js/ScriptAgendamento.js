function validarPaciente(){
    var paciente = document.getElementById("txPaciente").value
    
    if(paciente == ""){
        document.getElementById('resultado').innerHTML = 'Preencha o campo "Nome do Paciente" de forma correta!'
        return false;
    }else{
        return true;
    }
}


function validarNumero(){
    var numero = document.getElementById("txNumero").value
    
    if(numero.length != 1){
        document.getElementById('resultado').innerHTML = 'Preencha o campo "Número" de forma correta!'
        return false;
    }else{
        return true;
    }
}

function validarProfissional(){
    var profissional = document.getElementById("txProfissional").value
    
    if(profissional == ""){
        document.getElementById('resultado').innerHTML = 'Preencha o campo "Profissional" de forma correta!'
        return false;
    }else{
        return true;
    }
}

function validarCrm(){
    var crm = document.getElementById("txcrm").value
    
    if(crm.length != 14){
        document.getElementById('resultado').innerHTML = 'Preencha o campo "CRM" de forma correta!'
        return false;
    }else{
        return true;
    }
}

function validarEspecialidade(){
    var especialidade = document.getElementById("txEspecialidade").value
    
    if(especialidade == ""){
        document.getElementById('resultado').innerHTML = 'Preencha o campo "Especialidade" de forma correta!'
        return false;
    }else{
        return true;
    }
}

function validarClinica(){
    var clinica = document.getElementById("txClinica").value
    
    if(clinica == ""){
        document.getElementById('resultado').innerHTML = 'Preencha o campo "Clínica" de forma correta!'
        return false;
    }else{
        return true;
    }
}

function validarTudo(){
    if(validarPaciente() && validarNumero() && validarProfissional() && validarCrm() && validarEspecialidade() && validarClinica()){ 
        alert("Seus dados foram enviados!").style="background-color:#fff";
        return true;
    }else{
        return false;
    }
}