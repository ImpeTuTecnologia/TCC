function validarNome(){
    var nome = document.getElementById("txNome").value
    
    if(nome == ""){
        document.getElementById('resultado').innerHTML = 'Preencha o campo "Nome" de forma correta!'
        return false;
    }else{
        return true;
    }
}

function validarCnpj(){
    var cnpj = document.getElementById("txCnpj").value
    
    if(cnpj.length != 18 ){
        document.getElementById('resultado').innerHTML = 'Preencha o campo "CNPJ" de forma correta!'
        return false;
    }else{
        return true;
    }
}

function validarInscricao(){
    var inscricao = document.getElementById("txInscricao").value
    
    if(inscricao.length != 11 ){
        document.getElementById('resultado').innerHTML = 'Preencha o campo "Inscrição estadual" de forma correta!'
        return false;
    }else{
        return true;
    }
}

function validarArea(){
    var area = document.getElementById("txArea").value
    
    if(area == ""){
        document.getElementById('resultado').innerHTML = 'Preencha o campo "Área atuante" de forma correta!'
        return false;
    }else{
        return true;
    }
}

function validarResponsavel(){
    var responsavel = document.getElementById("txResponsavel").value
    
    if(responsavel == ""){
        document.getElementById('resultado').innerHTML = 'Preencha o campo "Responsável legal" de forma correta!'
        return false;
    }else{
        return true;
    }
}

function validarCpf(){
    var cpf = document.getElementById("txCpf").value
    
    if(cpf.length != 14){
        document.getElementById('resultado').innerHTML = 'Preencha o campo "CPF" de forma correta!'
        return false;
    }else{
        return true;
    }
}

function validarEndereco(){
    var endereco = document.getElementById("txEndereco").value
    
    if(endereco == ""){
        document.getElementById('resultado').innerHTML = 'Preencha o campo "Endereço" de forma correta!'
        return false;
    }else{
        return true;
    }
}

function validarN(){
    var n = document.getElementById("txN").value
    
    if(n == ""){
        document.getElementById('resultado').innerHTML = 'Preencha o campo "N°" de forma correta!'
        return false;
    }else{
        return true;
    }
}

function validarCompl(){
    var compl = document.getElementById("txCompl").value
    
    if(compl == ""){
        document.getElementById('resultado').innerHTML = 'Preencha o campo "Complemento" de forma correta!'
        return false;
    }else{
        return true;
    }
}

function validarCep(){
    var cep = document.getElementById("txCep").value
    
    if(cep.length != 9){
        document.getElementById('resultado').innerHTML = 'Preencha o campo "CEP" de forma correta!'
        return false;
    }else{
        return true;
    }
}

function validarBairro(){
    var bairro = document.getElementById("txBairro").value
    
    if(bairro == ""){
        document.getElementById('resultado').innerHTML = 'Preencha o campo "Bairro" de forma correta!'
        return false;
    }else{
        return true;
    }

}function validarCidade(){
    var cidade = document.getElementById("txCidade").value
    
    if(cidade == ""){
        document.getElementById('resultado').innerHTML = 'Preencha o campo "Cidade" de forma correta!'
        return false;
    }else{
        return true;
    }
}

function validarFone(){
    var fone = document.getElementById("txFone").value
    
    if(fone.length != 14){
        document.getElementById('resultado').innerHTML = 'Preencha o campo "Telefone" de forma correta!'
        return false;
    }else{
        return true;
    }
}

function validarCell(){
    var cell = document.getElementById("txCell").value
    
    if(cell.length != 15){
        document.getElementById('resultado').innerHTML = 'Preencha o campo "Celular" de forma correta!'
        return false;
    }else{
        return true;
    }
}

function validarEmail(){
    var email = document.getElementById("txEmail").value
    
    if(email == ""){
        document.getElementById('resultado').innerHTML = 'Preencha o campo "Email" de forma correta!'
        return false;
    }else{
        return true;
    }
}

function validarSenhaConfirmar(){
    var senha = document.getElementById("txSenha").value
    var confirmar = document.getElementById("txConfirmar").value
    
    if(senha.length < 8 ){
        document.getElementById('resultado').innerHTML = 'Preencha o campo "Senha" com no minímo 8 caracteres!'
        return false;
    }
    
    if(confirmar != senha){
        document.getElementById('resultado').innerHTML = 'Confirme sua senha!'
        return false;
    }
    
    else{
        return true;
    }
}

function validarTudo(){
    if(validarNome() && validarCnpj() && validarInscricao() && validarArea() && validarResponsavel() && validarCpf() && validarEndereco() &&
       validarEndereco() && validarN() && validarCompl() && validarCep() && validarBairro() && validarCidade() && validarFone() &&
       validarCell() && validarEmail() && validarSenhaConfirmar()){ 
        alert("Seus dados foram cadastrados!")
        return true;
    }else{
        return false;
    }
}