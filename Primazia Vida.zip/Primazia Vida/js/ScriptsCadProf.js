
function validarNome(){
    var nome = document.getElementById("txNome").value
    
    if(nome == ""){
        document.getElementById('resultado').innerHTML = 'Preencha o campo "Nome" de forma correta!'
        return false;
    }else{
        return true;
    }
}

function validarSobrenome(){
    var sobrenome = document.getElementById("txSobrenome").value
    
    if(sobrenome == ""){
        document.getElementById('resultado').innerHTML = 'Preencha o campo "Sobrenome" de forma correta!'
        return false;
    }else{
        return true;
    }
}

function validarRegistro(){
    var registro = document.getElementById("txRegistro").value
    
    if(registro == ""){
        document.getElementById('resultado').innerHTML = 'Preencha o campo "Número do registro" de forma correta!'
        return false;
    }else{
        return true;
    }
}

function validarArea(){
    var area = document.getElementById("txArea").value
    
    if(area == ""){
        document.getElementById('resultado').innerHTML = 'Preencha o campo "Área que exerce" de forma correta!'
        return false;
    }else{
        return true;
    }
}

function validarRg(){
    var rg = document.getElementById("txRg").value
    
    if(rg.length != 12){
        document.getElementById('resultado').innerHTML = 'Preencha o campo "RG" de forma correta!'
        return false;
    }else{
        return true;
    }
}

function validarCpf(){
    var cpf = document.getElementById("txCpf").value
    
    if(cpf.length != 14){
        document.getElementById('resultado').innerHTML = 'Preencha o campo "CPF" de forma correta!'
        return false;
    }else{
        return true;
    }
}

function validarEmail(){
    var email = document.getElementById("txEmail").value
    
    if(email == ""){
        document.getElementById('resultado').innerHTML = 'Preencha o campo "Email" de forma correta!'
        return false;
    }else{
        return true;
    }
}

function validarSenhaConfirmar(){
    var senha = document.getElementById("txSenha").value
    var confirmar = document.getElementById("txConfirmar").value
    
    if(senha.length < 8 ){
        document.getElementById('resultado').innerHTML = 'Preencha o campo "Senha" com no minímo 8 caracteres!'
        return false;
    }
    
    if(confirmar != senha){
        document.getElementById('resultado').innerHTML = 'Confirme sua senha!'
        return false;
    }
    
    else{
        return true;
    }
}

function validarTudo(){
    if(validarNome() && validarSobrenome() && validarRegistro() && validarArea() && validarRg() && validarCpf() && validarEmail() && 
       validarSenhaConfirmar()){ 
        alert("Seus dados foram cadastrados!")
        return true;
    }else{
        return false;
    }
}