<?php

    require("../Classes/conexao.php");
    $idClinica = $_GET['idClinica'];
    

    try{
        $stmt = $pdo -> prepare ("delete from tbpaciente where idClinica = '$idClinica'");
        $stmt -> execute();

        header("Location:../Home.php");

    }catch(PDOException $e){
        echo "Erro: " . $e -> getMessage();

    }

?>