<?php
            
    // $nomePaciente = $_POST['nome'];
    $idPaciente = $_POST['idPaciente'];
    // $nomeProfissional = $_POST['profissional'];
    $crm = $_POST['crm'];
    $esp = $_POST['especialidade'];
    $data = $_POST['data'];
    $hora = $_POST['horario'];


            include("../Classes/conexao.php");

            try{
                
                $stmt = $pdo->prepare("insert into consulta values (null, '$data', '$hora', '$esp', '$idPaciente', '$crm')");
                
                $stmt ->execute();

                $pdo = null;

                header("Location: ../Perfil-Clinica.php");
                
            }catch(PDOException $e){
                echo "ERRO: " . $e->getMessage();
            }
?>