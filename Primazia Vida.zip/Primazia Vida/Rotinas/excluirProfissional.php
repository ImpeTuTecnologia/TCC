<?php

    require("../Classes/conexao.php");
    $crm = $_GET['id'];
    

    try{
        $stmt = $pdo -> prepare ("delete from tbmedico where idMedico = '$crm'");
        $stmt -> execute();

        header("Location:../PerfilClinica.php");

    }catch(PDOException $e){
        echo "Erro: " . $e -> getMessage();

    }

?>