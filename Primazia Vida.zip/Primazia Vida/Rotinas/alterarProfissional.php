<?php

    include("../Classes/conexao.php");
    // $idMedico = $_POST['idMedico'];
    $nome = $_POST['nome'];
    // $crm = $_POST['numero'];
    $area = $_POST['area'];
    $data = $_POST['data'];
    $telefone = $_POST['telefone'];
    $celular = $_POST['celular'];
    $rg = $_POST['rg'];
    $cpf = $_POST['cpf'];
    

    try{
        $stmt = $pdo -> prepare ("update tbmedico set nomeMedico = '$nome', especialidade = '$area', 
            dataNascimento = '$data', rgM = '$rg', cpfM = '$cpf', telefone = '$telefone', celular = '$celular'");
        $stmt -> execute();

        header("Location: ../Perfil-Profissional.php");

    }catch(PDOException $e){
        echo "Erro: " . $e -> getMessage();

    }

?>