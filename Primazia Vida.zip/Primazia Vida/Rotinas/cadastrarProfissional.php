<?php
    $nome = $_POST['nome'];
    // $sobrenome = $_POST['sobrenome'];
    $crm = $_POST['numero'];
    $area = $_POST['area'];
    $data_Nasc = $_POST['data'];
    $rg = $_POST['rg'];
    $cpf = $_POST['cpf'];
    $telefone = $_POST['telefone'];
    $celular = $_POST['celular'];
    $email = $_POST['email'];
    $senha = $_POST['senha'];

    $senha_Cripto = md5($senha);

    include("../Classes/conexao.php");

        try{
    
            $stmt = $pdo->prepare("insert into tbmedico values ('$crm', '$nome', '$area', '$data_Nasc', '$rg', 
            '$cpf', '$telefone', '$celular', '$email', '$senha_Cripto')");
    
            $stmt ->execute();

            $pdo = null;

            header("Location: ../Perfil-Clinica.php");

        }catch(PDOException $e){
        echo "ERRO: " . $e->getMessage();
    }
?>

            
            