<?php
    include('../Classes/conexao.php');


$opcao = $_POST['opcao'];

if (isset($_POST['email']) && isset($_POST['senha']) && $pdo != null) {

    switch ($opcao) {
        case 1:
            $query = $pdo->prepare("SELECT * FROM tbpaciente WHERE email = ? AND senha = ?");
            $query->execute(array($_POST['email'], md5($_POST['senha'])));

            if ($query->rowCount()) {
                $paciente = $query->fetchAll(PDO::FETCH_ASSOC)[0];

                session_start();
                $_SESSION["paciente"] = array($paciente["idPaciente"], $paciente["nome"]);

                header('Location: ../chatPaciente.php');
            } else {
                header('Location: ../Formularios/login.php');
                
            }

            break;

        case 2:
            $query = $pdo->prepare("SELECT * FROM tbclinica WHERE email = ? AND senha = ?");
            $query->execute(array($_POST['email'], md5($_POST['senha'])));

            if ($query->rowCount()) {
                $clinica = $query->fetchAll(PDO::FETCH_ASSOC)[0];

                session_start();
                $_SESSION["clinica"] = array($clinica["idClinica"], $clinica["nome"]);

                header('Location: ../Perfil-Clinica.php');
            } else {
                header('Location: ../Formularios/login.php');
                
            }

            break;


            case 3:
                $query = $pdo->prepare("SELECT * FROM tbmedico WHERE email = ? AND senha = ?");
                $query->execute(array($_POST['email'], md5($_POST['senha'])));
    
                if ($query->rowCount()) {
                    $profissional = $query->fetchAll(PDO::FETCH_ASSOC)[0];
    
                    session_start();
                    $_SESSION["profissional"] = array($profissional["idMedico"], $profissional["nomeMedico"]);
    
                    header('Location: ../chatProfissional.php');
                } else {
                    header('Location: ../Formularios/login.php');
                    
                }
    
                break;

        default:
            header('Location: ../Formularios/login.php');
            
            
    }
} else {
    header('Location: ../Formularios/login.php');
    
}

?>