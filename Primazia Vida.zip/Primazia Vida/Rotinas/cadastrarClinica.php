<?php
            
    $nome = $_POST['nome'];
    $cnpj = $_POST['cnpj'];
    $inscricao_Estadual = $_POST['inscrição'];
    $data_inicio = $_POST['data'];
    $responsavel = $_POST['responsável'];
    $cpf_responsavel = $_POST['cpf'];
    $endereco = $_POST['endereço'];
    $numlog = $_POST['n'];
    $complemento = $_POST['complemento'];
    $cep = $_POST['cep'];
    $bairro = $_POST['bairro'];
    $cidade = $_POST['cidade'];
    $uf = $_POST['uf'];
    $telefone = $_POST['telefone'];
    $celular = $_POST['celular'];
    $email = $_POST['email'];
    $senha = $_POST['senha'];

    $senha_Cripto = md5($senha);

        include("../Classes/conexao.php");

            try{
                
                $stmt = $pdo->prepare("insert into tbclinica values (null, '$nome', '$cnpj', '$data_inicio', '$inscricao_Estadual', '$responsavel', 
                '$cpf_responsavel', '$uf', '$cidade', '$cep', '$bairro', '$endereco', 
                    '$numlog', '$complemento', '$telefone', '$celular', '$email', '$senha_Cripto')");
                
                $stmt ->execute();

                $pdo = null;

                header("Location: ../Formularios/login.php");
                
            }catch(PDOException $e){
                echo "ERRO: " . $e->getMessage();
            }
?>