<?php
    
    include("../Classes/conexao.php");
    $idAdm = $_SESSION['idAdm'];

    $nome = $_POST['nome'];
    $cpf = $_POST['cpf'];
    $rg = $_POST['rg'];
    $sexo = $_POST['sexo'];
    $dataNasc = $_POST['dataNasc'];
    $uf = $_POST['uf'];
    $cidade = $_POST['cidade'];
    $bairro = $_POST['bairro'];
    $cep = $_POST['cep'];
    $logradouro = $_POST['logradouro'];
    $numero = $_POST['numero'];
    $complemento = $_POST['complemento'];
    $celular = $_POST['celular'];
    $email = $_POST['email'];
    $senha = $_POST['senha'];
    $senha_cripto = md5($senha);

    
    
    

        try{
    
            $stmt = $pdo->prepare("insert into tbAdm (nome, cpf, rg, sexo, data_nascimento, uf, cidade, cep, bairro, logradouro, numero, complemento, email, senha) values('$nome', '$cpf', '$rg', '$sexo', '$dataNasc', '$uf', '$cidade', '$cep', '$bairro', '$logradouro', '$numero', '$complemento', '$email','$senha_cripto')");
    
            $stmt ->execute();

            $stmt = $pdo->prepare("insert into tbcontato_adm values(null, '$idAdm', '$celular')");

            $stmt->execute();

            $pdo = null;

            header('Location: ../Login/login.php');

        }catch(PDOException $e){
        echo "ERRO: " . $e->getMessage();
        }
?>