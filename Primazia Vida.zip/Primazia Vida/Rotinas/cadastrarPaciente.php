<?php
    $nome = $_POST['nome'];
    $data = $_POST['data'];
    $telefone = $_POST['telefone'];
    $celular = $_POST['celular'];
    $sexo = $_POST['sexo'];
    $logradouro = $_POST['log'];
    $numlog = $_POST['numero'];
    $cidade = $_POST['cidade'];
    $bairro = $_POST['bairro'];
    $uf = $_POST['uf'];
    $cep = $_POST['cep'];
    $rg = $_POST['rg'];
    $cpf = $_POST['cpf'];
    $email = $_POST['email'];
    $senha = $_POST['senha'];

    $senha_Cripto = md5($senha);

    include("../Classes/conexao.php");

        try{
    
            // $stmt = $pdo->prepare("insert into tbpaciente values (null, '$nome', '$cpf', '$rg', '$sexo', '$data',  
            // '$uf', '$cidade', '$cep', '$bairro',  '$logradouro',  '$numlog', '$telefone',  '$celular', '$email', '$senha_Cripto' )");
    
            // $stmt ->execute();

            // $pdo = null;

            // header("Location: ../Formularios/login.php");

            $stmt = $pdo->prepare("insert into tbpaciente (nome, cpf, rg, sexo, dataNascimento, uf, cidade, cep, bairro, logradouro, numero, telefone, celular, email, senha) values 
            ('$nome', '$cpf','$rg', '$sexo', '$data', '$uf','$cidade', '$cep', '$bairro', '$logradouro', '$numlog', '$telefone', '$celular', '$email', '$senha_Cripto')");
    
            $stmt ->execute();

            $pdo = null;

            header("Location:../Formularios/login.php");
            
            

        }catch(PDOException $e){
        echo "ERRO: " . $e->getMessage();
    }

?>

            
            