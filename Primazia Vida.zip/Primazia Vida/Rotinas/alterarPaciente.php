<?php

    require("../Classes/conexao.php");
    // $idPaciente = $_POST['idPaciente'];
    $nome = $_POST['nome'];
    $data = $_POST['data'];
    $telefone = $_POST['telefone'];
    $celular = $_POST['celular'];
    $sexo = $_POST['sexo'];
    $logradouro = $_POST['log'];
    $numlog = $_POST['numero'];
    $cidade = $_POST['cidade'];
    $bairro = $_POST['bairro'];
    $uf = $_POST['uf'];
    $cep = $_POST['cep'];
    $rg = $_POST['rg'];
    $cpf = $_POST['cpf'];

    try{
        $stmt = $pdo -> prepare ("update tbpaciente set nome = '$nome', cpf = '$cpf', 
            rg = '$rg', dataNascimento = '$data',  uf = '$uf',  cidade = '$cidade', cep = '$cep', 
                bairro = '$bairro', logradouro = '$logradouro', numero = '$numlog', telefone = '$telefone', celular = '$celular'");
        $stmt -> execute();

        header("Location:../Perfil-Paciente.php");

    }catch(PDOException $e){
        echo "Erro: " . $e -> getMessage();

    }

?>