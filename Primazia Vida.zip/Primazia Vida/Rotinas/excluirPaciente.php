<?php

    require("../Classes/conexao.php");
    $idPaciente = $_GET['id'];
    

    try{
        $stmt = $pdo -> prepare ("delete from tbpaciente where idPaciente = '$idPaciente'");
        $stmt -> execute();

        header("Location:../Home.php");

    }catch(PDOException $e){
        echo "Erro: " . $e -> getMessage();

    }

?>