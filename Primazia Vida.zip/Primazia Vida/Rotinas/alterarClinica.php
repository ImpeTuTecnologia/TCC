<?php

    require("../Classes/conexao.php");
    // $idClinica = $_POST['idClinica'];
    $nome = $_POST['nome'];
    // $data_inicio = $_POST['data'];
    $cnpj = $_POST['cnpj'];
    $inscricao_Estadual = $_POST['inscrição'];
    $data_inicio = $_POST['data'];
    $responsavel = $_POST['responsável'];
    $cpf_responsavel = $_POST['cpf'];
    $endereco = $_POST['endereço'];
    $numlog = $_POST['n'];
    $complemento = $_POST['complemento'];
    $cep = $_POST['cep'];
    $bairro = $_POST['bairro'];
    $cidade = $_POST['cidade'];
    $uf = $_POST['uf'];
    $telefone = $_POST['telefone'];
    $celular = $_POST['celular'];
    

    try{
        $stmt = $pdo->prepare("update tbclinica set nome = '$nome', cnpj = '$cnpj', data_inicio = '$data_inicio', inscricaoEstadual = '$inscricao_Estadual', responsaveLegal = '$responsavel', 
            cpfResponsavel = '$cpf_responsavel', logradouro = '$endereco', numero = '$numlog', complemento = '$complemento', cep = '$cep', bairro = '$bairro', cidade='$cidade', uf = '$uf', 
                telefone = '$telefone', celular = '$celular'");
        $stmt -> execute();

        header("Location:../Perfil-Clinica.php");

    }catch(PDOException $e){
        echo "Erro: " . $e -> getMessage();

    }

?>