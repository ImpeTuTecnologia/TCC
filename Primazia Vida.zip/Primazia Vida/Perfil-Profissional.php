<?php include("Classes/conexao.php");
session_start();
if(isset($_SESSION["profissional"]) && is_array($_SESSION["profissional"])){
  $idMedico = $_SESSION["profissional"][0];
  $nome = $_SESSION["profissional"][1];
}
else{
  header("Location: Login/login.php");
}
  //  $idPaciente = $_GET['idPaciente'];
  try{
    $stmt = $pdo -> prepare ("select * from tbmedico where idMedico = '$idMedico'");
    $stmt -> execute();
    $row = $stmt ->fetch(PDO::FETCH_BOTH);
  }catch(PDOException $e){
    echo "ERRO: " . $e->getMessage();
  }
  
?> 

<!DOCTYPE html>
<html lang="pt-BR">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Perfil</title>
    <link
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css"
      rel="stylesheet"
      integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl"
      crossorigin="anonymous"
    />
    <link
      rel="stylesheet"
      href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.0/font/bootstrap-icons.css"
    />

    <link rel="stylesheet" href="css/style.css" />
    <link rel="stylesheet" href="css/Style2.css" />
    <link rel="stylesheet" href="css/perfis.css" />
    <link rel="stylesheet" href="css/bootstrap.min.css" />
    <link rel="stylesheet" href="css/bootstrap-grid.min.css" />
    <link
      rel="stylesheet"
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css"
    />
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js"></script>
    <link
      rel="stylesheet"
      href="https://cdn.jsdelivr.net/npm/boxicons@latest/css/boxicons.min.css"
    />
    <link rel="icon" href="img/logoBranco.png" />
    <script
      src="https://code.jquery.com/jquery-3.3.1.slim.min.js"
      integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo"
      crossorigin="anonymous"
    ></script>
    <script
      src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"
      integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49"
      crossorigin="anonymous"
    ></script>
    <script
      src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"
      integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy"
      crossorigin="anonymous"
    ></script>
    <link
      rel="stylesheet"
      href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css"
      integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk"
      crossorigin="anonymous"
    />

    <!-- <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous"> -->

    <script
      src="https://kit.fontawesome.com/fdbc06b9ad.js"
      crossorigin="anonymous"
    ></script>
    <script src="js/perfis.js"></script>
  </head>

  <body id="body-pd" style="background-image: none;">
    <div class="l-navbar" id="nav-bar">
      <nav class="nav">
        <div>
          <a href="#" style="text-decoration: none" class="nav_logo" active>
            <i class="fas fa-user-md nav_logo-icon"></i><br />
          </a>
          <div class="nav_list">
            <a href="#" style="text-decoration: none" class="nav_link">
              <i class="fas fa-file nav_icon"></i><br />
              <span class="nav_name">Arquivos</span>
            </a>
            
            <a href="chatProfissional.php" style="text-decoration: none" class="nav_link">
              <i class="fas fa-stethoscope nav_icon"></i><br />
              <span class="nav_name">Consultas</span>
            </a>
            
            <a href="agendaProfissional.php" style="text-decoration: none" class="nav_link">
              <i class="fas fa-calendar-alt nav_icon"></i><br />
              <span class="nav_name">Agenda</span>
            </a>
          </div>
        </div>
        <a href="#" style="text-decoration: none" class="nav_link">
          <i class="fas fa-cog nav_icon"></i><br />
          <span class="nav_name">Config</span>
        </a>
      </nav>
    </div>


    <a href="Rotinas/logout.php"><i class="fas fa-sign-out-alt" data-toggle="tooltip" data-placement="bottom" title="Sair" id="iconSignOut"></i></a><br>
    <i class="fas fa-user-circle" id="iconUser"></i>
    <i class="fas fa-user-edit iconEdit" data-toggle="tooltip" data-placement="right" title="Editar Foto"></i>
      <b><h1 id="title_nome" style="overflow-y:hidden; margin-left:33%;"><?php echo $row['nomeMedico']; ?></h1></b>

      <h2 class="titulosEditDelete" style="overflow-y:hidden;">Dados do Perfil<i class="fas fa-edit iconEdit" data-toggle="tooltip" data-placement="right" title="Editar Dados"></i></h2>
      
      <hr>
      
    <br />
     <!-- FORMULÁRIO DE ALTERAÇÃO -->
     <div class="container">
      <div class="row justify-content-center mb-5">
        <div class="col-sm12 col-md-10 col-lg-8">
          <section>
            <form class="formulario"
              action="Rotinas/alterarProfissional.php"
              method="POST"
              onsubmit="return validarTudo()"
            >
              <div class="form-row">
              
                  
                <br>
                <div class="form-grup col-sm-4 col-md-4 col-lg-4">
                  <label for="LabelNome"><b>Nome:</b></label>
                  <input
                    type="text"
                    class="form-control"
                    name="nome"
                    id="txNome"
                    placeholder="Nome..."
                    value="<?php echo $row['nomeMedico']; ?>"
                    style="border-color: #a71930"
                  />
                </div>

                <div class="form-grup col-sm-4 col-md-4 col-lg-4">
                  <label for="labelCidade"><b>CRM: </b></label>
                  <input
                    type="text"
                    class="form-control"
                    name="numero"
                    id="txRegistro"
                    placeholder="Registro..."
                    value="<?php echo $row['idMedico']; ?>"
                    style="border-color: #a71930"
                  />
                </div>

                <div class="form-grup col-sm-4 col-md-4 col-lg-4">
                  <label for="labelCidade"><b>Área que exerce: </b></label>
                  <input
                    type="text"
                    class="form-control"
                    name="area"
                    id="txArea"
                    value="<?php echo $row['especialidade']; ?>"
                    placeholder="Exemplo: Cardiologista"
                    style="border-color: #a71930"
                  />
                </div>
              </div>

              <div class="form-row">
                <div class="form-grup col-sm-4 col-md-4 col-lg-4">
                  <label for="LabelNome"><b>Data de Nascimento: </b></label>
                  <input
                    type="date"
                    class="form-control"
                    name="data"
                    id="txData"
                    value="<?php echo $row['dataNascimento']; ?>"
                    placeholder="Idade..."
                    style="border-color: #a71930"
                  />
                </div>

                <div class="form-grup col-sm-4 col-md-4 col-lg-4">
                  <label for="LabelSobreNome"><b>RG: </b></label>
                  <input
                    type="text"
                    class="form-control"
                    name="rg"
                    value="<?php echo $row['rgM']; ?>"
                    onkeypress="$(this).mask('00.000.000-0');"
                    id="txRg"
                    
                    placeholder="RG..."
                    style="border-color: #a71930"
                  />
                </div>

                <div class="form-grup col-sm-4 col-md-4 col-lg-4">
                  <label for="labelCidade"><b>CPF: </b></label>
                  <input
                    type="text"
                    onkeypress="$(this).mask('000.000.000-00');"
                    class="form-control"
                    
                    name="cpf"
                    value="<?php echo $row['cpfM']; ?>"
                    
                    id="txCpf"
                    placeholder="CPF..."
                    style="border-color: #a71930"
                  />
                </div>
              </div>
              

               
              </div>
              
              <div>
                <input
                  type="submit"
                  value="Salvar Alterações"
                  class="bt"
                  style="margin-bottom: 4%;margin-left: 45%;"
                  onclick="visualizarDados()"
                />
              </div>
            </form>
            
          </section>
          
        </div>
        
      </div>
      <section>
        <h2 class="titulosEditDelete" style="overflow-y:hidden;">Excluir Perfil</h2>
            <hr>
            <p id="informacaoExcluir">Se excluir a sua conta, os seus dados serão excluídos de forma permanente, atente-se e tenha certeza dessa ação.
              <button id="btEncerrar" type="button" onclick="confirmar()">
                Encerrar Conta
              </button>
            </p>
            
      </section>
      
      <section>
        <p id="resultado" class="result"></p>
      </section>
    </div>
  </body>
</html>
