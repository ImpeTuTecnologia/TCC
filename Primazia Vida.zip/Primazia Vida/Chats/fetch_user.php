

<?php

//fetch_user.php


include('database_connection.php');

session_start();

$query = "
SELECT * FROM login 
WHERE user_id != '".$_SESSION['user_id']."' 
";

$statement = $connect->prepare($query);

$statement->execute();

$result = $statement->fetchAll();

$output = '
<table style="width:60%; font-size:30px; text-align:center; margin-left:20%; background:#fff; border-bottom-left-radius: 20px; border-bottom-right-radius: 20px; 
border-top-left-radius: 20px; border-top-right-radius: 20px; box-shadow: 0 0 3em #A71930;">
 <tr>
  <td style="text-align:center; background:#A71930; border-top-left-radius: 20px; border-top-right-radius: 20px;
  padding: 10px; font-weight: bold; font-size:30px; color:#fff;">Pacientes</td>
 </tr>';

foreach($result as $row)
{
 $status = '';
 $current_timestamp = strtotime(date("Y-m-d H:i:s") . '- 10 second');
 $current_timestamp = date('Y-m-d H:i:s', $current_timestamp);
 $user_last_activity = fetch_user_last_activity($row['user_id'], $connect);
 if($user_last_activity > $current_timestamp)
 {
  $status = '<span class="label label-success">Online</span>';
 }
 else
 {
  $status = '<span class="label label-danger">Offline</span>';
 }
 $output .= '
 <tr>
  <td style="padding:10px; background: repeating-linear-gradient(#fff, LightPink)">'.$row['username'].' '.count_unseen_message($row['user_id'], $_SESSION['user_id'], $connect).' '.fetch_is_type_status($row['user_id'], $connect).' '.$status.'
  <button style="background: HotPink; width:110px; height:35px; font-size:20px; margin-top:3px; font-weight:bold;" type="button" class="btn btn-info btn-xs start_chat" data-touserid="'.$row['user_id'].'" 
  data-tousername="'.$row['username'].'">Conversar</button>'.'</td>
 </tr>
 ';
}

$output .= '</table>';

echo $output;

?>