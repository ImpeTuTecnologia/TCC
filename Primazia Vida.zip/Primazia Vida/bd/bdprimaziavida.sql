-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 24-Jun-2021 às 08:10
-- Versão do servidor: 10.4.18-MariaDB
-- versão do PHP: 8.0.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `bdprimaziavida`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `chat_message`
--

CREATE TABLE `chat_message` (
  `chat_message_id` int(11) NOT NULL,
  `to_user_id` int(11) NOT NULL,
  `from_user_id` int(11) NOT NULL,
  `chat_message` mediumtext COLLATE utf8mb4_bin NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

--
-- Extraindo dados da tabela `chat_message`
--

INSERT INTO `chat_message` (`chat_message_id`, `to_user_id`, `from_user_id`, `chat_message`, `timestamp`, `status`) VALUES
(1, 0, 0, '😙', '2021-06-20 20:44:15', 1),
(2, 1, 7, 'alo', '2021-06-23 13:21:35', 1),
(3, 1, 7, 'Olá', '2021-06-23 13:48:56', 1),
(4, 1, 7, 'Arrombado', '2021-06-23 13:49:05', 1);

-- --------------------------------------------------------

--
-- Estrutura da tabela `consulta`
--

CREATE TABLE `consulta` (
  `idConsulta` int(11) NOT NULL,
  `dataConsulta` date NOT NULL,
  `horaConsulta` time NOT NULL,
  `especialidade` int(60) NOT NULL,
  `idPaciente` int(11) NOT NULL,
  `idMedico` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `consulta`
--

INSERT INTO `consulta` (`idConsulta`, `dataConsulta`, `horaConsulta`, `especialidade`, `idPaciente`, `idMedico`) VALUES
(4, '2021-06-26', '15:00:00', 0, 15, 21738274);

-- --------------------------------------------------------

--
-- Estrutura da tabela `login`
--

CREATE TABLE `login` (
  `user_id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `login`
--

INSERT INTO `login` (`user_id`, `username`, `password`) VALUES
(8, 'Rogério Santos', '$2y$10$5uo8uEOM03aylmebGPBj4.x1woVQhtPwG/JttL5tZ/zz0fOOpB7tS'),
(9, 'Marcela Alves', '$2y$10$vW3/LLihJSHu1iHJkV/HHuDBzWAsBoEi9ReI7JRuddQrGoKjtuSrO');

-- --------------------------------------------------------

--
-- Estrutura da tabela `login_details`
--

CREATE TABLE `login_details` (
  `login_details_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `last_activity` timestamp NOT NULL DEFAULT current_timestamp(),
  `is_type` enum('no','yes') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `login_details`
--

INSERT INTO `login_details` (`login_details_id`, `user_id`, `last_activity`, `is_type`) VALUES
(1, 0, '2021-06-20 21:23:47', 'no'),
(2, 7, '2021-06-23 13:49:26', 'no'),
(3, 8, '2021-06-24 02:48:09', 'no'),
(4, 9, '2021-06-24 03:52:10', 'no'),
(5, 8, '2021-06-24 03:37:28', 'no'),
(6, 8, '2021-06-24 03:59:46', 'no'),
(7, 9, '2021-06-24 03:59:43', 'no'),
(8, 9, '2021-06-24 04:51:27', 'no'),
(9, 8, '2021-06-24 05:01:15', 'no');

-- --------------------------------------------------------

--
-- Estrutura da tabela `tbadm`
--

CREATE TABLE `tbadm` (
  `idAdm` int(11) NOT NULL,
  `nome` varchar(150) DEFAULT NULL,
  `cpf` varchar(11) DEFAULT NULL,
  `rg` varchar(9) DEFAULT NULL,
  `sexo` char(1) DEFAULT NULL,
  `data_nascimento` date DEFAULT NULL,
  `uf` varchar(2) DEFAULT NULL,
  `cidade` varchar(150) DEFAULT NULL,
  `cep` varchar(8) DEFAULT NULL,
  `bairro` varchar(150) DEFAULT NULL,
  `logradouro` varchar(250) DEFAULT NULL,
  `numero` varchar(5) DEFAULT NULL,
  `complemento` varchar(5) DEFAULT NULL,
  `email` varchar(150) DEFAULT NULL,
  `senha` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estrutura da tabela `tbclinica`
--

CREATE TABLE `tbclinica` (
  `idClinica` int(11) NOT NULL,
  `nome` varchar(150) DEFAULT NULL,
  `cnpj` varchar(20) DEFAULT NULL,
  `data_inicio` date NOT NULL,
  `inscricaoEstadual` varchar(20) DEFAULT NULL,
  `responsaveLegal` varchar(150) DEFAULT NULL,
  `cpfResponsavel` varchar(14) DEFAULT NULL,
  `uf` varchar(2) DEFAULT NULL,
  `cidade` varchar(150) DEFAULT NULL,
  `cep` varchar(14) DEFAULT NULL,
  `bairro` varchar(150) DEFAULT NULL,
  `logradouro` varchar(150) DEFAULT NULL,
  `numero` varchar(5) DEFAULT NULL,
  `complemento` varchar(5) DEFAULT NULL,
  `telefone` varchar(14) NOT NULL,
  `celular` varchar(14) NOT NULL,
  `email` varchar(150) DEFAULT NULL,
  `senha` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `tbclinica`
--

INSERT INTO `tbclinica` (`idClinica`, `nome`, `cnpj`, `data_inicio`, `inscricaoEstadual`, `responsaveLegal`, `cpfResponsavel`, `uf`, `cidade`, `cep`, `bairro`, `logradouro`, `numero`, `complemento`, `telefone`, `celular`, `email`, `senha`) VALUES
(5, 'Clínica Saudade', '12.323.435/4654-65', '2007-04-24', '23.748937-3', 'Rodrigo Alves', '483.938.948-32', 'SP', 'São Paulo', '08460-365', 'Jardim São Paulo(Zona Leste)', 'Rua Feliciano de Mendonça', '78', '', '(11) 2556-5743', '(11) 9454-6563', 'clinicasaudade@gmail.com', '25d55ad283aa400af464c76d713c07ad');

-- --------------------------------------------------------

--
-- Estrutura da tabela `tbcontato_clinica`
--

CREATE TABLE `tbcontato_clinica` (
  `idContatoClinica` int(11) NOT NULL,
  `idClinica` int(11) NOT NULL,
  `telefone` varchar(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estrutura da tabela `tbconvenio`
--

CREATE TABLE `tbconvenio` (
  `idConvenio` int(11) NOT NULL,
  `idClinica` int(11) NOT NULL,
  `nome` varchar(75) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estrutura da tabela `tbdepartamento`
--

CREATE TABLE `tbdepartamento` (
  `idDepartamento` int(11) NOT NULL,
  `idClinica` int(11) NOT NULL,
  `nome` varchar(150) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estrutura da tabela `tbespecialidade`
--

CREATE TABLE `tbespecialidade` (
  `idEspecialidade` int(11) NOT NULL,
  `nome` varchar(75) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `tbespecialidade`
--

INSERT INTO `tbespecialidade` (`idEspecialidade`, `nome`) VALUES
(1, 'Acupuntura'),
(2, 'Alergia e Imunologia'),
(3, 'Anestesiologia'),
(4, 'Angiologia'),
(5, 'Cancerologia'),
(6, 'Cardiologia'),
(7, 'Cirurgia Cardiovascular'),
(8, 'Cirurgia da Mão'),
(9, 'Cirurgia de Cabeça e Pescoço'),
(10, 'Cirurgia do Aparelho Digestivo'),
(11, 'Cirurgia Geral'),
(12, 'Cirurgia Pediátrica'),
(13, 'Cirurgia Plástica'),
(14, 'Cirurgia Torácica'),
(15, 'Cirurgia Vascular'),
(16, 'Clínica Médica'),
(17, 'Coloproctologia'),
(18, 'Dermatologia'),
(19, 'Endocrinologia e Metabologia'),
(20, 'Endoscopia'),
(21, 'Gastroenterologia'),
(22, 'Genética Médica'),
(23, 'Geriatria'),
(24, 'Ginecologia e Obstetrícia'),
(25, 'Hematologia e Hemoterapia'),
(26, 'Homeopatia'),
(27, 'Infectologia'),
(28, 'Mastologia'),
(29, 'Medicina de Família e Comunidade'),
(30, 'Medicina do Trabalho'),
(31, 'Medicina de Tráfego'),
(32, 'Medicina Esportiva'),
(33, 'Medicina Física e Reabilitação'),
(34, 'Medicina Intensiva'),
(35, 'Medicina Legal e Perícia Médica'),
(36, 'Medicina Nuclear'),
(37, 'Medicina Preventiva e Social'),
(38, 'Nefrologia'),
(39, 'Neurocirurgia'),
(40, 'Neurologia'),
(41, 'Nutrologia'),
(42, 'Oftalmologia'),
(43, 'Ortopedia e Traumatologia'),
(44, 'Otorrinolaringologia'),
(45, 'Patologia'),
(46, 'Patologia Clínica/Medicina Laboratorial'),
(47, 'Pediatria'),
(48, 'Pneumologia'),
(49, 'Psiquiatria'),
(50, 'Radiologia e Diagnóstico por Imagem'),
(51, 'Radioterapia'),
(52, 'Reumatologia'),
(53, 'Urologia'),
(54, 'Áreas de Atuação reconhecidas'),
(55, 'Administração em Saúde'),
(56, 'Alergia e Imunologia Pediátrica'),
(57, 'Angiorradiologia e Cirurgia Endovascular'),
(58, 'Atendimento ao queimado'),
(59, 'Cardiologia Pediátrica'),
(60, 'Cirurgia Crânio-Maxilo-Facial'),
(61, 'Cirurgia do Trauma'),
(62, 'Cirurgia Videolaparoscópica'),
(63, 'Citopatologia'),
(64, 'Densitometria Óssea'),
(65, 'Dor'),
(66, 'Ecocardiografia'),
(67, 'Ecografia Vascular com Doppler'),
(68, 'Eletrofisiologia Clínica Invasiva'),
(69, 'Endocrinologia Pediátrica'),
(70, 'Endoscopia Digestiva'),
(71, 'Endoscopia Ginecológica'),
(72, 'Endoscopia Respiratória'),
(73, 'Ergometria'),
(74, 'Foniatria'),
(75, 'Gastroenterologia Pediátrica'),
(76, 'Hansenologia'),
(77, 'Hematologia e Hemoterapia Pediátrica'),
(78, 'Hemodinâmica e Cardiologia Intervencionista'),
(79, 'Hepatologia'),
(80, 'Infectologia Hospitalar'),
(81, 'Infectologia Pediátrica'),
(82, 'Mamografia'),
(83, 'Medicina de Urgência'),
(84, 'Medicina do Adolescente'),
(85, 'Medicina do Sono'),
(86, 'Medicina Fetal'),
(87, 'Medicina Intensiva Pediátrica'),
(88, 'Medicina Paliativa'),
(89, 'Medicina Tropical'),
(90, 'Nefrologia Pediátrica'),
(91, 'Neonatologia'),
(92, 'Neurofisiologia Clínica'),
(93, 'Neurologia Pediátrica'),
(94, 'Neurorradiologia'),
(95, 'Nutrição Parenteral e Enteral'),
(96, 'Nutrição Parenteral e Enteral Pediátrica'),
(97, 'Nutrologia Pediátrica'),
(98, 'Pneumologia Pediátrica'),
(99, 'Psicogeriatria'),
(100, 'Psicoterapia'),
(101, 'Psiquiatria da Infância e Adolescência'),
(102, 'Psiquiatria Forense'),
(103, 'Radiologia Intervencionista e Angiorradiologia'),
(104, 'Reumatologia Pediátrica'),
(105, 'Sexologia'),
(106, 'Transplante de Medula Óssea'),
(107, 'Ultrassonografia em Ginecologia e Obstetrícia');

-- --------------------------------------------------------

--
-- Estrutura da tabela `tbmedico`
--

CREATE TABLE `tbmedico` (
  `idMedico` varchar(14) NOT NULL,
  `nomeMedico` varchar(150) DEFAULT NULL,
  `especialidade` varchar(70) NOT NULL,
  `dataNascimento` date NOT NULL,
  `rgM` varchar(14) NOT NULL,
  `cpfM` varchar(14) NOT NULL,
  `telefone` varchar(14) NOT NULL,
  `celular` varchar(14) NOT NULL,
  `email` varchar(150) DEFAULT NULL,
  `senha` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `tbmedico`
--

INSERT INTO `tbmedico` (`idMedico`, `nomeMedico`, `especialidade`, `dataNascimento`, `rgM`, `cpfM`, `telefone`, `celular`, `email`, `senha`) VALUES
('72634763-7', 'Cristina Oliveira', 'Cardiologia', '1994-09-23', '47.657.365-3', '273.627.437-66', '', '', 'cristina@dra.com', '25d55ad283aa400af464c76d713c07ad');

-- --------------------------------------------------------

--
-- Estrutura da tabela `tbpaciente`
--

CREATE TABLE `tbpaciente` (
  `idPaciente` int(11) NOT NULL,
  `nome` varchar(150) DEFAULT NULL,
  `cpf` varchar(14) DEFAULT NULL,
  `rg` varchar(14) DEFAULT NULL,
  `sexo` char(10) DEFAULT NULL,
  `dataNascimento` date DEFAULT NULL,
  `uf` varchar(15) DEFAULT NULL,
  `cidade` varchar(150) DEFAULT NULL,
  `cep` varchar(14) DEFAULT NULL,
  `bairro` varchar(150) DEFAULT NULL,
  `logradouro` varchar(150) DEFAULT NULL,
  `numero` varchar(5) DEFAULT NULL,
  `telefone` varchar(14) NOT NULL,
  `celular` varchar(14) NOT NULL,
  `email` varchar(150) DEFAULT NULL,
  `senha` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `tbpaciente`
--

INSERT INTO `tbpaciente` (`idPaciente`, `nome`, `cpf`, `rg`, `sexo`, `dataNascimento`, `uf`, `cidade`, `cep`, `bairro`, `logradouro`, `numero`, `telefone`, `celular`, `email`, `senha`) VALUES
(15, 'Mário Gonçalves', '237.826.473-64', '47.362.476-3', 'Masculino', '1999-09-27', 'AC', 'São Paulo', '03694-000', 'Parque Paineiras', 'Avenida Águia de Haia', '45', '(11) 2847-3838', '(11) 98347-236', 'mario129@outlook.com', '25d55ad283aa400af464c76d713c07ad');

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `chat_message`
--
ALTER TABLE `chat_message`
  ADD PRIMARY KEY (`chat_message_id`);

--
-- Índices para tabela `consulta`
--
ALTER TABLE `consulta`
  ADD PRIMARY KEY (`idConsulta`),
  ADD KEY `idPaciente` (`idPaciente`),
  ADD KEY `idMedico` (`idMedico`);

--
-- Índices para tabela `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`user_id`);

--
-- Índices para tabela `login_details`
--
ALTER TABLE `login_details`
  ADD PRIMARY KEY (`login_details_id`);

--
-- Índices para tabela `tbadm`
--
ALTER TABLE `tbadm`
  ADD PRIMARY KEY (`idAdm`),
  ADD UNIQUE KEY `cpf` (`cpf`),
  ADD UNIQUE KEY `rg` (`rg`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Índices para tabela `tbclinica`
--
ALTER TABLE `tbclinica`
  ADD PRIMARY KEY (`idClinica`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Índices para tabela `tbcontato_clinica`
--
ALTER TABLE `tbcontato_clinica`
  ADD PRIMARY KEY (`idContatoClinica`),
  ADD KEY `idClinica` (`idClinica`);

--
-- Índices para tabela `tbconvenio`
--
ALTER TABLE `tbconvenio`
  ADD PRIMARY KEY (`idConvenio`),
  ADD KEY `idClinica` (`idClinica`);

--
-- Índices para tabela `tbdepartamento`
--
ALTER TABLE `tbdepartamento`
  ADD PRIMARY KEY (`idDepartamento`),
  ADD KEY `idClinica` (`idClinica`);

--
-- Índices para tabela `tbespecialidade`
--
ALTER TABLE `tbespecialidade`
  ADD PRIMARY KEY (`idEspecialidade`);

--
-- Índices para tabela `tbmedico`
--
ALTER TABLE `tbmedico`
  ADD PRIMARY KEY (`idMedico`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Índices para tabela `tbpaciente`
--
ALTER TABLE `tbpaciente`
  ADD PRIMARY KEY (`idPaciente`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `chat_message`
--
ALTER TABLE `chat_message`
  MODIFY `chat_message_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de tabela `consulta`
--
ALTER TABLE `consulta`
  MODIFY `idConsulta` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de tabela `login`
--
ALTER TABLE `login`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT de tabela `login_details`
--
ALTER TABLE `login_details`
  MODIFY `login_details_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT de tabela `tbadm`
--
ALTER TABLE `tbadm`
  MODIFY `idAdm` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `tbclinica`
--
ALTER TABLE `tbclinica`
  MODIFY `idClinica` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de tabela `tbcontato_clinica`
--
ALTER TABLE `tbcontato_clinica`
  MODIFY `idContatoClinica` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `tbconvenio`
--
ALTER TABLE `tbconvenio`
  MODIFY `idConvenio` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `tbdepartamento`
--
ALTER TABLE `tbdepartamento`
  MODIFY `idDepartamento` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `tbespecialidade`
--
ALTER TABLE `tbespecialidade`
  MODIFY `idEspecialidade` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=108;

--
-- AUTO_INCREMENT de tabela `tbpaciente`
--
ALTER TABLE `tbpaciente`
  MODIFY `idPaciente` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- Restrições para despejos de tabelas
--

--
-- Limitadores para a tabela `tbcontato_clinica`
--
ALTER TABLE `tbcontato_clinica`
  ADD CONSTRAINT `tbcontato_clinica_ibfk_1` FOREIGN KEY (`idClinica`) REFERENCES `tbclinica` (`idClinica`);

--
-- Limitadores para a tabela `tbconvenio`
--
ALTER TABLE `tbconvenio`
  ADD CONSTRAINT `tbconvenio_ibfk_1` FOREIGN KEY (`idClinica`) REFERENCES `tbclinica` (`idClinica`);

--
-- Limitadores para a tabela `tbdepartamento`
--
ALTER TABLE `tbdepartamento`
  ADD CONSTRAINT `tbdepartamento_ibfk_1` FOREIGN KEY (`idClinica`) REFERENCES `tbclinica` (`idClinica`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
