

<?php include("Classes/conexao.php");
  //  $idPaciente = $_GET['idPaciente'];
session_start();
if(isset($_SESSION["clinica"]) && is_array($_SESSION["clinica"])){
  $idClinica = $_SESSION["clinica"][0];
  $nome = $_SESSION["clinica"][1];
}
else{
  header("Location: Login/login.php");
}
  try{
    $stmt = $pdo -> prepare ("select * from tbclinica where idClinica = '$idClinica'");
    $stmt -> execute();
    $row = $stmt ->fetch(PDO::FETCH_BOTH);
  }catch(PDOException $e){
    echo "ERRO: " . $e->getMessage();
  }
  
?> 

<!DOCTYPE html>
<html lang="pt-BR">
  <head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="icon" href="img/logoBranco.png" />
    <link rel="stylesheet" href="css/bootstrap-grid.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.0/font/bootstrap-icons.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/Style2.css">
    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://kit.fontawesome.com/fdbc06b9ad.js" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
    
    <title>Perfil Clínica</title>
    <style>
      /* .agenda{
        text-align: center;
        margin-top: 50px;
        font-size: 35px;
        font-weight: bold;
        font-family: Arial, Helvetica, sans-serif;
      } */

      .formu{
        text-align: center;
        
      }

      form .inp1{
        margin-top: 50px;
        font-family: Arial, Helvetica, sans-serif;
      }

      form .inp2{
        margin-top: 40px;
        font-family: Arial, Helvetica, sans-serif;
      }

      form .btt{
        margin-top: 40px;
        font-family: Arial, Helvetica, sans-serif;
        border-radius: 20px;
        border: 1px solid black;
        padding: 4px;
        background-color: #A71930;
      }

      form input{
        border-radius: 20px;
        border: 1px solid black;
        padding: 2px;
      }

      form select{
        border-radius: 20px;
        border: 1px solid black;
        padding: 2px;
      }

      .col-6-1{
        background-color: #F08080;
        margin-left: 27%;
        margin-top: 4%;
        border-radius: 20%;
      }

      #bt_flutuante{
          position: fixed;
          bottom:35px;
          right:30px;
          /* cursor: pointer; */
          width: 60px;
          height: 60px;
          border-radius: 30px;
          background-color: #57010f;
          border: none;
          font-size: 24px;
          color: white;
          
      }

      #btEnviar{
        background-color: #A71930;
        border:none;
      }

      .required:after{
      content: " *";
      color: red;
      } 
    </style>

    <script
    src="js/ScriptAgendamento.js"
    ></script>
  </head>

  <body style="background-image: none;">
  
    <nav class="navbar navbar-expand-lg navbar-light bg-" style="background-color: #A71930;">
      <div class="container-fluid">
        <a class="navbar-brand" href="#"><img src="img/primaziaVinho.jpg" width="180" height="110"></a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarText" aria-controls="navbarText" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarText">
          <ul class="navbar-nav me-auto mb-2 mb-lg-0"></ul>
        </div>
        
      </div>
    </nav>
        <br>
        <a href="Rotinas/logout.php" style="margin-left:97%; color:#57010f;">
    <i
      class="fas fa-sign-out-alt"
      data-toggle="tooltip"
      data-placement="bottom"
      title="Sair"
      id="iconSignOut"
      ></i
    >
    </a><br />
    <div class="row1">
      <div class="col-4-1"><br>
        <div style="display:flex;
          align-items: center;
          justify-content: center;
          height: 292px;">
                                
          <ul class="list-group list-group-flush"> 
              <li class="list-group-item" style="font-size:1.5em;">Nome: <?php echo $row['nome']; ?><br></li>
              <li class="list-group-item" >CNPJ: <?php echo $row['cnpj']; ?></li>
              <li class="list-group-item" >Responsável: <?php echo $row['responsaveLegal']; ?></li>
              <li class="list-group-item" >Endereço: <?php echo $row['logradouro']; ?></li>
              <li class="list-group-item" >Telefone: <?php echo $row['telefone']; ?></li>
              <li class="list-group-item" >Email: <?php echo $row['email']; ?></li>
          </ul>
          <div style="margin-left: 30%;"><i class="fas fa-hospital-user fa-5x" style="margin-bottom: 15px; color:#fff;"></i>

            <div class="d-grid gap-2 mx-auto" style="background-color:pink; height: 38px; overflow-y:hidden;">
              <button class="btn" type="button"><a href="Formularios/Editar-Clinica.php" style="text-decoration:none; color:#A71930; overflow-y:hidden;">Editar</a></button>
              <a href="#" style="text-decoration:none;color:#fff;">Redefinir senha</a><br>
            </div>
          </div>
        </div><br>
        <div style="display:flex;
          align-items: center;
          justify-content: center;
          background-color: #FFB6C1;
          height: 191px;
          width: 702px;
         ">

          <div class="d-grid gap-2 mx-auto" style="background-color:#A71930;">
          <button id="btEncerrar" type="button" style="background-color:#A71930;">
              <a href="Rotinas/excluirClinica.php?idClinica=$row[idClinica]\" style="text-decoration:none; color:#fff;" onclick="return confirm('Excluir conta?(Esta ação fará com que todos os dados do perfil sejam deletados permanentemente)')">Excluir Conta</a>
              </button>
          </div>
        </div>
      </div>
      <div class="col-4-2" style="background-color: pink; width:500;">
        <div class="container">
          <div class="d-grid gap-2 mx-auto" style="background-color:#A71930; margin-top: 15px;">
            <button class="btn" style="color:pink" type="button"><a href="Formularios/Cadastro-Profissional.php">Adicionar Profissionais</a></button>
          </div><br>
          <table class="table table-hover">
            <thead>
              <tr>
                <th scope="col"></th>
                <th scope="col">CRM</th>
                <th scope="col">Nome</th>
                <!-- <th scope="col"></th> -->
                <th scope="col"></th>
              </tr>
            </thead>
            <tbody>
              <?php

                include("Classes/conexao.php");
    
    
                  try {
                    $stmt = $pdo -> prepare("select * from tbmedico"); 
    
                    $stmt -> execute();
    
                        while ($row = $stmt -> fetch(PDO::FETCH_BOTH)){ 
                                    
                                            
                          echo"<tr>";
                                  
                            echo"<th scope='row'><i class='fas fa-user-circle view_data'  data-toggle='modal' data-target='#exampleModal1' 
                              data-whatever='@mdo' data-placement='bottom' title='Visualizar Perfil' id='iconUser" .$row['idMedico']. "'></i></th>";
                            echo"<td>".$row['idMedico']."</td>";
                            echo"<td>".$row['nomeMedico']."</td>";
                            // echo"<td><a href='Perfil-Profissional.php?id=". $row['crm']." ' style='text-decoration:none;'>Editar</a></td>";
                            echo"<td><a href='Rotinas/excluirProfissional.php?id=". $row['idMedico']. " ' style='text-decoration:none;' onclick='return confirm('Excluir conta?(Esta ação fará com que todos os dados do perfil sejam deletados permanentemente)')'>Excluir</a></td>";
                          echo"</tr>";
                        }
                    }
                    catch(PDOException $e){
                        echo("Erro: ".$e -> getMessage());
                  }
    
                ?>
                                
              </tbody>
            </table>
          </div> 
        </div>
        <?php
          include("Classes/conexao.php");
          try{
            $stmt = $pdo -> prepare ("select * from tbmedico where idMedico = '21738274-8'");
            $stmt -> execute();
            $row = $stmt ->fetch(PDO::FETCH_BOTH);
          }catch(PDOException $e){
            echo "ERRO: " . $e->getMessage();
          }
        ?>
        <div
          class="modal fade"
          id="exampleModal1"
          tabindex="-1"
          role="dialog"
          aria-labelledby="exampleModalLabel"
          aria-hidden="true"
        >
          <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
              <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Perfil</h5>
                <button
                  type="button"
                  class="close"
                  data-dismiss="modal"
                  aria-label="Fechar"
                  style="background-color: #fff; border:none;"
                >
                  <span aria-hidden="true">&times;</span>
                </button>
              </div>
              <div class="modal-body">
                  <div style="margin-left:37%;">
                    <i class="fas fa-user-md" id="iconPerfil"></i><br>
                    <h1 id="name titlePerfil" style="overflow-y:hidden;"><?php echo $row['nomeMedico']; ?></h1>     
                  </div>
                  <div class="row" style="margin-top: 5%;"> 
                    <div class="col-md-4" style="margin-left: 10%; overflow-y: hidden;"><h4 style="overflow-y:hidden;">Área de Atuação:</h4></div>
                    <div class="col-md-4 ml-auto" style="margin-left: 20%; overflow-y: hidden;"><h4 style="overflow-y:hidden;">Email:</h4></div>
                  </div>
                  <div class="row"> 
                    <div class="col-md-4" style="margin-left: 10%;"><p><?php echo $row['especialidade']; ?></p></div>
                    <div class="col-md-4 ml-auto" style="margin-left: 15%; overflow-y: hidden;"><p><?php echo $row['email'];?></p></div>
                  </div>
                  <div class="row" style="margin-top: 5%;"> 
                    <div class="col-md-4" style="margin-left: 10%;"><h4 style="overflow-y:hidden;">Telefone:</h4></div>
                    <div class="col-md-4 ml-auto" style="margin-left: 20%; overflow-y: hidden;"><h4 style="overflow-y:hidden;">Celular:</h4></div>
                  </div>
                  <div class="row"> 
                    <div class="col-md-4" style="margin-left: 10%;"><p><?php echo $row['telefone']; ?></p></div>
                    <div class="col-md-4 ml-auto" style="margin-left: 20%;"><p><?php echo $row['celular']; ?></p></div>
                  </div>
              
              </div>
            </div>
          </div>
        </div><br> 
        <h2 class="titulosEditDelete" style="overflow-y:hidden; color:#000; font-family:arial;">Consultas Marcadas</h2>
            <hr><br>
        <table class="table table-bordered" style="margin-bottom:3%;">
          <thead style="background-color: #A71930">
            <tr>
              <th scope="col" style="color:#fff;">Data e Horário</th>
              <th scope="col" style="color:#fff;">Médico</th>
              <th scope="col" style="color:#fff;">Especialidade</th>
              <th scope="col" style="color:#fff;">Paciente</th>
              <th scope="col"></th>
              <th scope="col"></th>
            </tr>
          </thead>
          <tbody>
              <?php
    
                include("Classes/conexao.php");
      
                try {
                  $stmt = $pdo -> prepare("select * from consulta  
                  inner join tbpaciente on consulta.idPaciente = tbpaciente.idPaciente
                    inner join tbmedico on consulta.idMedico = tbmedico.idMedico");
  
                $stmt -> execute();
      
                    while ($row = $stmt -> fetch(PDO::FETCH_BOTH)){ 
                                      
                                              
                      echo"<tr>";       
                      echo"<th scope='row'>" .$row['dataConsulta']. " às " . $row['horaConsulta'] . "</th>";
                      echo"<td>" . $row['nomeMedico'] . "</td>";
                      echo"<td>" . $row['especialidade'] . "</td>";
                      echo"<td>" . $row['nome'] . "</td>";
                      echo"<td><a href='#?id=". $row['idConsulta']. " ' style='text-decoration:none;' >Editar</a></td>";
                      echo"<td><a href='#?id=". $row['idConsulta']. " ' style='text-decoration:none;' onclick='return confirm('Excluir Consulta?(Esta ação fará com que todos os dados da consulta sejam deletados permanentemente)')'>Excluir</a></td>";
                      echo"</tr>";
                    }
                  }
                  catch(PDOException $e){
                      echo("Erro: ".$e -> getMessage());
                  }
      
              ?>
          </tbody>
        </table>

        <!--botão flutuante-->
        <button
          type="button"
          id="bt_flutuante"
          class="btn btn-primary"
          data-placement="top"
          title="Agendar"
          data-toggle="modal"
          data-target="#exampleModal"
          data-whatever="@mdo"
        >
          <i class="fas fa-calendar-plus"></i>
        </button>

      <div
      class="modal fade"
      id="exampleModal"
      tabindex="-1"
      role="dialog"
      aria-labelledby="exampleModalLabel"
      aria-hidden="true"
    >
      <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Marcar Consulta</h5>
            <button
              type="button"
              class="close"
              data-dismiss="modal"
              aria-label="Fechar"
            >
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
            <form action="Rotinas/agendarConsulta.php" method="POST" >
            <!-- onsubmit="return validarTudo()" -->
              <div class="form-group">
                <label for="recipient-name" class="col-form-label required"
                  >Nome do Paciente</label
                >
                <input type="text" class="form-control" id="txPaciente" name="nome"/>
                          
              </div>
              <div class="form-group">
                <label for="recipient-name" class="col-form-label required"
                  >Identificação do Paciente</label
                >
                <input type="text" class="form-control" id="txNumero" name="idPaciente"/>
              </div>
          
              <div class="form-group">
                <label for="recipient-name" class="col-form-label required"
                  >Profissional</label
                >
                <input type="text" class="form-control" id="txProfissional" name="profissional"/>
              </div>
              <div class="form-group">
                <label for="recipient-name" class="col-form-label required"
                  >CRM</label
                >
                <input type="text" class="form-control" id="txcrm" name="crm"/>
              </div>
              <div class="form-group">
                <label for="recipient-name" class="col-form-label required"
                  >Especialidade(Ex: Psicologia)</label
                >
                <input type="text" class="form-control" id="txEspecialidade" name="especialidade"/>
              </div>
                        
              <div class="form-group">
                <label for="recipient-name" class="col-form-label required"
                  >Data da Consulta</label
                >
                <input type="date" class="form-control" id="recipient-name" name="data"/>
              </div>
              <div class="form-group">
                <label for="recipient-name" class="col-form-label required"
                  >Horário da Consulta</label
                >
                <input type="time" class="form-control" id="recipient-name" name="horario"/>
              </div>
              </div>
              <!-- <section>
                <p id="resultado" class="result"></p>
              </section> -->
              <div class="modal-footer">
                <button
                  type="button"
                  class="btn btn-secondary"
                  data-dismiss="modal"
                >
                  Fechar
                </button>
                <input type="submit" value= "Marcar na Agenda" class="btn btn-primary" id="btEnviar"/>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div><br>
    <footer class=" text-white text-center text-lg-start" style="background-color: #A71930; padding:8px">
   <!-- Grid container -->
 <!-- Copyright -->
 <div class="vida">&copy; PRIMAZIA VIDA 2021</div>
 <!-- Copyright -->
</footer> 
 
  </body>
</html>

