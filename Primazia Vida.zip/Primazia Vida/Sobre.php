<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />

    <link
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css"
      rel="stylesheet"
      integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl"
      crossorigin="anonymous"
    />
    <link
      rel="stylesheet"
      href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.0/font/bootstrap-icons.css"
    />
    <link rel="stylesheet" href="css/style.css" />
    <link rel="stylesheet" href="css/Style2.css" />
    <link rel="stylesheet" href="css/Style3.css" />
    <link rel="stylesheet" href="css/bootstrap-grid.min.css" />

    <link rel="icon" href="img/logoBranco.png" />
    <title>Sobre</title>
  </head>
  <body>
  <nav class="navbar navbar-expand-lg navbar-light bg-" style="background-color: #A71930;">
  <div class="container-fluid">
    <a class="navbar-brand" href="#"><img src="img/primaziaVinho.jpg" width="210" height="130"></a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarText" aria-controls="navbarText" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarText">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="Formularios/Cadastro-Paciente.php" style="font-size: 20px; font-weight:bold;">Cadastrar-se</a>
        </li>
        <li class="nav-item">
        <a class="nav-link active" aria-current="page" href="Formularios/login.php" style="font-size: 20px; font-weight:bold;">Fazer Login</a>
        </li>
        <li class="nav-item">
        <a class="nav-link active" aria-current="page" href="Formularios/Cadastro-Clinica.php" style="font-size: 20px; font-weight:bold;">Cadastre sua clínica</a>
        </li>
      </ul>
      <a class="nav-link active" aria-current="page" href="Sobre.php" style="font-size: 20px; color:black; font-weight:bold;">
        Sobre o Primazia Vida!
      </a>
    </div>
  </div>
</nav>
    <br />

    <br /><br />
    <p
      style="
        color: #a71930;
        font-family: Bahnschrift Condensed;
        font-size: 75px;
        font-weight: bold;
        text-transform: uppercase;
        text-align: center;
      "
    >
      Sobre
    </p>
    <br /><br />

    <div class="row">
      <div class="col-6">
        <p class="tituloSobre">Praticidade e conforto</p>
        <p class="textoSobre">
          Uma plataforma agradável para o cliente, de fácil adesão e
          manuseio.<br />
          Foi desenvolvida justamente para que se encaixe no seu dia a dia, para
          que você utilize sem muitas dificuldades.
        </p>
      </div>
      <div class="col-6">
        <img src="img/criança.jpg" alt="" class="imagensSobre" />
      </div>
    </div>

    <div class="row">
      <div class="col-6">
        <img src="img/médico.jpg" alt="" class="imagensSobre" />
      </div>
      <div class="col-6">
        <p class="tituloSobre">Comunicação direta com seu médico</p>
        <p class="textoSobre">
          Um canal direto entre médico e paciente, com a mesma qualidade do
          presencial, mas ainda melhor, podendo ter um consultório da onde
          estiver.
        </p>
      </div>
    </div>

    <div class="row">
      <div class="col-6">
        <p class="tituloSobre">acessível a toda família</p>
        <p class="textoSobre">
          Todos podem utilizar, pois atende diversas áreas da madicina, com os
          melhores médicos do mercado.
        </p>
      </div>
      <div class="col-6">
        <img src="img/familia.jpg" alt="" class="imagensSobre" />
      </div>
    </div>

    <br />
    <footer class=" text-white text-center text-lg-start" style="background-color: #A71930;">
    <!-- Grid container -->
      <!-- Footer Links -->
  <div class="container text-center text-md-left">

    <!-- Grid row -->
    <div class="row">

      <!-- Grid column -->
      <hr class="clearfix w-100 d-md-none">

      <!-- Grid column -->
      <div class="col-md-4 col-lg-3 mx-auto my-md-4 my-0 mt-4 mb-1">

        <!-- Contact details -->
        <h5 class="email">E-Mail</h5>

        <ul class="list-unstyled">
          <li>
              <p class="email2">PrimaziaVida@gmail.com</p>
          </li>
        </ul>

      </div>
      <!-- Grid column -->

      <hr class="clearfix w-100 d-md-none">

      <!-- Grid column -->
      <div class="col-md-4 col-lg-3 mx-auto my-md-4 my-0 mt-4 mb-1">

        <!-- Contact details -->
        <h5 class="insta">Instagram</h5>

        <ul class="list-unstyled">
          <li>
              <p class="insta2">@PrimaziaVida(Oficial)</p>
          </li>
        </ul>

      </div>
      <!-- Grid column -->

      <hr class="clearfix w-100 d-md-none">

      <!-- Grid column -->
      <div class="col-md-4 col-lg-3 mx-auto my-md-4 my-0 mt-4 mb-1">

        <!-- Contact details -->
        <h5 class="yt">Youtube</h5>

        <ul class="list-unstyled">
          <li>
              <p class="yt2">Primazia Vida Oficial</p>
          </li>
        </ul>

      </div>
      <!-- Grid column -->

      <hr class="clearfix w-100 d-md-none">

      <!-- Grid column -->
      <div class="col-md-4 col-lg-3 mx-auto my-md-4 my-0 mt-4 mb-1">

        <!-- Contact details -->
        <h5 class="emp">Empresa</h5>

        <ul class="list-unstyled">
          <li>
              <a href="#"><p class="emp2">ImpetuTecnologia.com</p></a>
          </li>
        </ul>

      </div>
      <!-- Grid column -->

    </div>
    <!-- Grid row -->

  </div>
  <!-- Footer Links -->

  <!-- Copyright -->
  <div class="vida">&copy; PRIMAZIA VIDA 2021</div>
  <!-- Copyright -->

</footer>
<!-- Footer -->
  </body>
</html>
