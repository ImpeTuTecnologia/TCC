<?php

    //Dados para acesso ao banco de dados
    $servidor = "localhost";
    $banco = "bdprimaziavida";
    $usuario = "root";
    $senha = "Bac9123G14cg";



    $pdo;

    try{

        //Criando a conexão com o banco
        $pdo = new PDO("mysql:host=$servidor;dbname=$banco",$usuario,$senha);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    }
    catch(PDOException $e){
        echo "ERRO:" . $e->getMessage();
        $pdo = null;
        exit;
    }
