<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.0/font/bootstrap-icons.css">
    <link rel="stylesheet" type="text/css" href="css/style.css"/>
    <link rel="stylesheet" type="text/css" href="css/Style2.css"/>
    <link rel="stylesheet" href="css/bootstrap-grid.min.css">

    <link rel="icon" href="img/logoBranco.png" />
    
        <title>Home</title>

</head>
<body>

  <nav class="navbar navbar-expand-lg navbar-light bg-" style="background-color: #A71930;">
  <div class="container-fluid">
    <a class="navbar-brand" href="#"><img src="img/primaziaVinho.jpg" width="210" height="130"></a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarText" aria-controls="navbarText" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarText">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="Formularios/Cadastro-Paciente.php" style="font-size: 20px; font-weight:bold;">Cadastrar-se</a>
        </li>
        <li class="nav-item">
        <a class="nav-link active" aria-current="page" href="Formularios/login.php" style="font-size: 20px; font-weight:bold;">Fazer Login</a>
        </li>
        <li class="nav-item">
        <a class="nav-link active" aria-current="page" href="Formularios/Cadastro-Clinica.php" style="font-size: 20px; font-weight:bold;">Cadastre sua clínica</a>
        </li>
      </ul>
      <a class="nav-link active" aria-current="page" href="Sobre.php" style="font-size: 20px; color:black; font-weight:bold;">
        Sobre o Primazia Vida!
      </a>
    </div>
  </div>
</nav>

        <div id="carouselExampleCaptions" class="carousel slide" data-bs-ride="carousel">
            <div class="carousel-indicators">
              <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
              <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="1" aria-label="Slide 2"></button>
              <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="2" aria-label="Slide 3"></button>
              <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="3" aria-label="Slide 4"></button>
            </div>
            <div class="carousel-inner">
              <div class="carousel-item active">
                <img src="img/img1.jpg" height="400" width="400" class="d-block w-100" alt="...">
                <div class="carousel-caption d-none d-md-block">
                  <h4 class="txt1">Em uma época de pandemia.</h4>
                  <h5 class="txt2">Todos viram o que a falta de cuidado com a saúde pode fazer.</h5>
                </div>
              </div>
              <div class="carousel-item">
                <img src="img/img3.jpg" height="400" width="400" class="d-block w-100" alt="...">
                <div class="carousel-caption d-none d-md-block">
                  <h4 class="txt1">Cuide de sua saúde do conforto da sua casa.</h4>
                  <h5 class="txt2">O atendimento que você não consegue encontrar, você vai encontrar aqui.</h5>
                </div>
              </div>
              <div class="carousel-item">
                <img src="img/img4.jpg" height="400" width="400" class="d-block w-100" alt="...">
                <div class="carousel-caption d-none d-md-block">
                  <h4 class="txt1">Cuide do seu corpo.</h4>
                  <h5 class="txt2">Não deixe sintomas anormais se prolongarem.</h5>
                </div>
              </div>
              <div class="carousel-item">
                <img src="img/img2.jpg" height="400" width="400" class="d-block w-100" alt="...">
                <div class="carousel-caption d-none d-md-block">
                  <h4 class="txt1">Cuide da sua alimentação</h4>
                  <h5 class="txt2">Ela é um dos fatores mais importantes para uma boa saúde.</h5>
                </div>
              </div>
            </div>
            <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions"  data-bs-slide="prev">
              <span class="carousel-control-prev-icon" aria-hidden="true"></span>
              <span class="visually-hidden">Previous</span>
            </button>
            <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions"  data-bs-slide="next">
              <span class="carousel-control-next-icon" aria-hidden="true"></span>
              <span class="visually-hidden">Next</span>
            </button>
          </div>

    <div class="blocos">
    <div class="atras">
    <p class="prof">GOSTARIA DE SE CADASTRAR E <br> OFERECER SEUS SERVIÇOS AGORA?</p> 
    <a href="Formularios-Cadastro/Cadastro-Clinica.php"><button class="botao">Clique aqui</button></a>
  </div>

  <div class="atras2">
    <p class="pv" >O QUE SERIA O PRIMAZIA VIDA?</p> 
    <p class="pv2"><br>O Primazia Vida conecta pessoas que querem cuidar da saúde, 
      com profissionais que tem disponibilidade para atendê-los, e tudo de uma forma simples e prática, se 
      quiser saber mais, basta conferir o guia na opção "Sobre" na parte superior do site.</p>
  </div>
</div>
    
      <div class="fundo">
        <div>
          <img src="img/Passo1.jpg" class="pv3" class="col-4">
          <img src="img/Passo2.jpg" class="pv4" class="col-4">
          <img src="img/Passo3.jpg" class="pv5" class="col-4">
        </div>

        <div>
          <p class="pv6" >Pesquise o profissional que necessita.</p>
          <p class="pv7" >Escolha o que mais lhe agradar.</p>
          <p class="pv8" >Solicite o atendimento que deseja.</p>
        </div>

          </div>

      <footer class=" text-white text-center text-lg-start" style="background-color: #A71930;">
    <!-- Grid container -->
      <!-- Footer Links -->
  <div class="container text-center text-md-left">

    <!-- Grid row -->
    <div class="row">

      <!-- Grid column -->
      <hr class="clearfix w-100 d-md-none">

      <!-- Grid column -->
      <div class="col-md-4 col-lg-3 mx-auto my-md-4 my-0 mt-4 mb-1">

        <!-- Contact details -->
        <h5 class="email">E-Mail</h5>

        <ul class="list-unstyled">
          <li>
              <p class="email2">PrimaziaVida@gmail.com</p>
          </li>
        </ul>

      </div>
      <!-- Grid column -->

      <hr class="clearfix w-100 d-md-none">

      <!-- Grid column -->
      <div class="col-md-4 col-lg-3 mx-auto my-md-4 my-0 mt-4 mb-1">

        <!-- Contact details -->
        <h5 class="insta">Instagram</h5>

        <ul class="list-unstyled">
          <li>
              <p class="insta2">@PrimaziaVida(Oficial)</p>
          </li>
        </ul>

      </div>
      <!-- Grid column -->

      <hr class="clearfix w-100 d-md-none">

      <!-- Grid column -->
      <div class="col-md-4 col-lg-3 mx-auto my-md-4 my-0 mt-4 mb-1">

        <!-- Contact details -->
        <h5 class="yt">Youtube</h5>

        <ul class="list-unstyled">
          <li>
              <p class="yt2">Primazia Vida Oficial</p>
          </li>
        </ul>

      </div>
      <!-- Grid column -->

      <hr class="clearfix w-100 d-md-none">

      <!-- Grid column -->
      <div class="col-md-4 col-lg-3 mx-auto my-md-4 my-0 mt-4 mb-1">

        <!-- Contact details -->
        <h5 class="emp">Empresa</h5>

        <ul class="list-unstyled">
          <li>
              <a href="#"><p class="emp2">ImpetuTecnologia.com</p></a>
          </li>
        </ul>

      </div>
      <!-- Grid column -->

    </div>
    <!-- Grid row -->

  </div>
  <!-- Footer Links -->

  <!-- Copyright -->
  <div class="vida">&copy; PRIMAZIA VIDA 2021</div>
  <!-- Copyright -->

</footer>
<!-- Footer -->

</body>
</html>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.bundle.min.js" integrity="sha384-b5kHyXgcpbZJO/tY9Ul7kGkf1S0CWuKcCD38l8YkeH8z8QjE0GmW1gYU5S9FOnJ0" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.6.0/dist/umd/popper.min.js" integrity="sha384-KsvD1yqQ1/1+IA7gi3P0tyJcT3vR+NdBTt13hSJ2lnve8agRGXTTyNaBYmCR/Nwi" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.min.js" integrity="sha384-nsg8ua9HAw1y0W1btsyWgBklPnCUAFLuTMS2G72MMONqmOymq585AcH49TLBQObG" crossorigin="anonymous"></script>