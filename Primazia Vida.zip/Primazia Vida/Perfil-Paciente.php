<?php 
include("Classes/conexao.php");
session_start();
if(isset($_SESSION["paciente"]) && is_array($_SESSION["paciente"])){
  $idPaciente = $_SESSION["paciente"][0];
  $nome = $_SESSION["paciente"][1];
}
else{
  header("Location: Login/login.php");
}


  //  $idPaciente = $_GET['idPaciente'];
  try{
    $stmt = $pdo -> prepare ("select * from tbpaciente where idPaciente = '$idPaciente'");
    $stmt -> execute();
    $row = $stmt ->fetch(PDO::FETCH_BOTH);
  }catch(PDOException $e){
    echo "ERRO: " . $e->getMessage();
  }
  
?> 

<!DOCTYPE html>
<html lang="pt-BR">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Perfil</title>
    <link
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css"
      rel="stylesheet"
      integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl"
      crossorigin="anonymous"
    />
    <link
      rel="stylesheet"
      href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.0/font/bootstrap-icons.css"
    />

    <link rel="stylesheet" href="css/style.css" />
    <link rel="stylesheet" href="css/Style2.css" />
    <link rel="stylesheet" href="css/perfis.css" />
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/bootstrap-grid.min.css" />
    <link
      rel="stylesheet"
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css"
    />
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js"></script>
    <link
      rel="stylesheet"
      href="https://cdn.jsdelivr.net/npm/boxicons@latest/css/boxicons.min.css"
    />
    <link rel="icon" href="img/logoBranco.png" />
    <script
      src="https://code.jquery.com/jquery-3.3.1.slim.min.js"
      integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo"
      crossorigin="anonymous"
    ></script>
    <script
      src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"
      integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49"
      crossorigin="anonymous"
    ></script>
    <script
      src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"
      integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy"
      crossorigin="anonymous"
    ></script>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
      
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">

    <script
      src="https://kit.fontawesome.com/fdbc06b9ad.js"
      crossorigin="anonymous"
    ></script>
    <script src="js/perfis.js"></script>
  </head>

  <body id="body-pd" style="background-image: none;">

    <div class="l-navbar" id="nav-bar">
      <nav class="nav">
        <div>
          <a href="#" style="text-decoration: none;" class="nav_logo">
            <i class="fas fa-user-circle nav_logo-icon" active></i><br />
          </a>
          <div class="nav_list">
            <a href="#" style="text-decoration: none;" class="nav_link">
              <i class="fas fa-history nav_icon"></i><br />
              <span class="nav_name">Histórico</span>
            </a>
            <a href="chatPaciente.php" style="text-decoration: none;" class="nav_link">
              <i class="fas fa-stethoscope nav_icon"></i><br />
              <span class="nav_name">Consultas</span>
            </a>
            <a href="agenda.php" style="text-decoration: none;" class="nav_link">
              <i class="fas fa-calendar-alt nav_icon"></i><br />
              <span class="nav_name">Agenda</span>
            </a>
          </div>
        </div>
        <a href="#" style="text-decoration: none;" class="nav_link">
          <i class="fas fa-cog nav_icon"></i><br />
          <span class="nav_name">Config</span>
        </a>
      </nav>
    </div>


    <p><b>Sua identificação: <?php  echo $row['idPaciente']; ?></b></p>
    <a href="Rotinas/logout.php"><i class="fas fa-sign-out-alt " data-toggle="tooltip" data-placement="bottom" title="Sair" id="iconSignOut"></i></a><br>
    <i class="fas fa-user-circle" id="iconUser"></i>
    <i class="fas fa-user-edit iconEdit" data-toggle="tooltip" data-placement="right" title="Editar Foto"></i>
      <b><h1 id="title_nome"style="overflow-y:hidden;"><?php echo $row['nome']; ?></h1></b>

      <h2 class="titulosEditDelete" style="overflow-y:hidden;">Dados do Perfil<i class="fas fa-edit iconEdit" data-toggle="tooltip" data-placement="right" title="Editar Dados"></i></h2>
      
      <hr>
      
    <br />
    <!-- FORMULÁRIO DE ALTERAÇÃO -->
    <div class="container">
     

      <div class="row justify-content-center mb-5">
        <div class="col-sm12 col-md-10 col-lg-8">
          <section>
            <form action="Rotinas/alterarPaciente.php" method="POST" onsubmit="return validarTudo()">
            <div class="form-row">
            <div class="form-grup col-sm-6 col-md-6 col-lg-6">

            <input type="hidden" class="form-control" name="idPaciente" id="txIdPaciente" placeholder="Nome..." value="<?php echo $row['idPaciente']; ?>" style="border-color: #A71930;">

          </div>
</div>

<div class="form-row">
<div class="form-grup col-sm-6 col-md-6 col-lg-6">

    <label for="LabelNome"><b>Nome: </b></label>
    <input type="text" class="form-control" name="nome" id="txNome" placeholder="Nome..." value="<?php echo $row['nome']; ?>" style="border-color: #A71930;">

 </div>

 <!-- <div class="form-grup col-sm-6 col-md-6 col-lg-6">

    <label for="LabelSobreNome"><b>Sobrenome: </b></label>
    <input type="text" class="form-control" name="sobrenome" id="txSobrenome" placeholder="Sobrenome..." style="border-color: #A71930;">
    
 </div> -->

 <div class="form-grup col-sm-6 col-md-6 col-lg-6">

   <label for="LabelNome"><b>Data de Nascimento: </b></label>
   <input type="date" class="form-control" name="data" id="txData" placeholder="Idade..." value="<?php echo $row['dataNascimento']; ?>" style="border-color: #A71930;">

</div>

</div>
<br>

<div class="form-row ">

<!-- <div class="form-group col-lg-7">
<label for="txHistorico" style="border-color: #752f3b; margin-left: 35%;"><b>Histórico Médico: </b></label>
<textarea class="form-control" name="historico" id="txHistorico" rows="3" placeholder="Exemplo: Asma" value="" style="border-color: #A71930; margin-left: 35%;"></textarea>
</div> -->
<!-- <div class="form-grup col-sm-6 col-md-6 col-lg-6">

<label for="LabelSobreNome"><b>Histórico Médico: </b></label>
<input type="text" class="form-control" name="historico" id="txHistorico" placeholder="Exemplo: Asma" style="border-color: #A71930;">

</div> -->

</div>
<br>

<div class="form-row">

<div class="form-grup col-sm-6 col-md-6 col-lg-6">

<label for="labelBairro"><b>Telefone: </b></label>
<input type="text" class="form-control" name="telefone" id="txFone"  style="border-color: #A71930;" placeholder="( __ )____-____"  value="<?php echo $row['telefone']; ?>" onkeypress="$(this).mask('(00) 0000-0000');"  >

</div>

<div class="form-grup col-sm-6 col-md-6 col-lg-6">

<label for="labelBairro"><b>Celular: </b></label>
<input type="text" class="form-control" name="celular" id="txCell" onkeypress="$(this).mask('(00) 00000-0000');" placeholder="( __ )____-____" value="<?php echo $row['celular']; ?>" style="border-color: #A71930;">

</div>

</div>
<br>
<div class="form-row">

<div class="form-grup col-sm-4 col-md-4 col-lg-4">

<label for="LabelNome"><b>Gênero: </b></label>
<select type="text" class="form-control" name="sexo" id="txSexo" value="<?php echo $row['sexo']; ?>" placeholder="Sexo..."  style="border-color: #A71930;">

<option value="Masculino">Masculino</option>
<option value="Feminino">Feminino</option>

</select>

</div>

<div class="form-grup col-sm-4 col-md-4 col-lg-4">

<label for="labelCidade"><b>CEP: </b></label>
<input type="text" class="form-control" name="cep" id="txCep" onkeypress="$(this).mask('00000-000');" placeholder="_____-___" value="<?php echo $row['cep']; ?>" style="border-color: #A71930;">

</div>

<div class="form-grup col-sm-4 col-md-4 col-lg-4">

<label for="LabelNome"><b>Logradouro: </b></label>
<input type="text" class="form-control" name="log" id="txLog" placeholder="Logradouro..." value="<?php echo $row['logradouro']; ?>" style="border-color: #A71930;">

</div>



</div><br>


<div class="form-row">

<div class="form-grup col-sm-4 col-md-4 col-lg-4">

<label for="LabelNome"><b>Número: </b></label>
<input type="text" class="form-control" name="numero" id="txNumero" placeholder="__" value="<?php echo $row['numero']; ?>" style="border-color: #A71930;">

</div>


<div class="form-grup col-sm-4 col-md-4 col-lg-4">

<label for="LabelSobreNome"><b>Bairro: </b></label>
<input type="text" class="form-control" name="bairro" id="txBairro" placeholder="Bairro..." value="<?php echo $row['bairro']; ?>" style="border-color: #A71930;">

</div>

<div class="form-grup col-sm-4 col-md-4 col-lg-4">

<label for="LabelNome"><b>Cidade: </b></label>
<input type="text" class="form-control" name="cidade" id="txCidade" placeholder="Cidade..." value="<?php echo $row['cidade']; ?>" style="border-color: #A71930;">

</div>




</div>
<br>

<div class="form-row">

<div class="form-grup col-sm-4 col-md-4 col-lg-4">

<label for="labelCep"><b>UF: </b></label>
<select type="text" class="form-control" name="uf" id="txUf"  value="<?php echo $row['uf']; ?>"placeholder="UF..."  style="border-color: #A71930;">


<option value="AC">Acre</option>
<option value="AL">Alagoas</option>
<option value="AP">Amapá</option>
<option value="AM">Amazonas</option>
<option value="BA">Bahia</option>
<option value="CE">Ceará</option>
<option value="DF">Distrito Federal</option>
<option value="ES">Espírito Santo</option>
<option value="GO">Goiás</option>
<option value="MA">Maranhão</option>
<option value="MT">Mato Grosso</option>
<option value="MS">Mato Grosso do Sul</option>
<option value="MG">Minas Gerais</option>
<option value="PA">Pará</option>
<option value="PB">Paraíba</option>
<option value="PR">Paraná</option>
<option value="PE">Pernambuco</option>
<option value="PI">Piauí</option>
<option value="RJ">Rio de Janeiro</option>
<option value="RN">Rio Grande do Norte</option>
<option value="RS">Rio Grande do Sul</option>
<option value="RO">Rondônia</option>
<option value="RR">Roraima</option>
<option value="SC">Santa Catarina</option>
<option value="SP">São Paulo</option>
<option value="SE">Sergipe</option>
<option value="TO">Tocantins</option>

</select>

</div>


  <div class="form-grup col-sm-4 col-md-4 col-lg-4">

      <label for="labelCidade"><b>RG: </b></label>
      <input type="text" class="form-control" name="rg" id="txRg" onkeypress="$(this).mask('00.000.000-0');" placeholder="__.___.___-_" value="<?php echo $row['rg']; ?>" style="border-color: #A71930;">

   </div>

      <div class="form-grup col-sm-12 col-md-4 col-lg-4">

    <label for="labelCep"><b>CPF: </b></label>
    <input type="text" class="form-control" name="cpf" id="txCpf" onkeypress="$(this).mask('000.000.000-00');" placeholder="___.___.___-__" value="<?php echo $row['cpf']; ?>" style="border-color: #A71930;">

 </div>
      </div>
      <br>

      <!-- <div class="form-row">

      
          <div class="form-grup col-sm-4 col-md-4 col-lg-4">

              <label for="labelCidade"><b>Crie sua senha: </b></label>
              <input type="password" class="form-control" name="senha" id="txSenha" placeholder="Senha..." style="border-color: #A71930;">

           </div>
     
  
              </div>
               <br> -->
              <div>
               <input type="submit" value="Salvar Alterações" class="bt"  style="margin-left:38%;" onclick="visualizarDados()" />
                    </div>
              
            </form>
            <br>
            
          </section>
      </div>
      <section>
      <h2 class="titulosEditDelete" style="overflow-y:hidden;">Excluir Perfil</h2>
            <hr>
            <p id="informacaoExcluir">Se excluir a sua conta, os seus dados serão excluídos de forma permanente, atente-se e tenha certeza dessa ação.
              <button id="btEncerrar" type="button">
              <a href="Rotinas/excluirPaciente.php?idPaciente=$row[idPaciente]\" style="text-decoration:none; color:#fff;" onclick="return confirm('Excluir conta?(Esta ação fará com que todos os dados do perfil sejam deletados permanentemente)')">Excluir Conta</a>
              </button>
            </p>
      </section>
      <section>
        <p id='resultado' class="result"></p>
      </section>
    </div>
  </body>
</html>

